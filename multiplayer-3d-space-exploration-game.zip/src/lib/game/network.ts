export type NetworkKind = "staralgo" | "broadcast";

export type WireMessage = {
  type: string;
  [key: string]: unknown;
};

type MessageHandler = (data: WireMessage, peerId: string) => void;
type PeerHandler = (peerId: string) => void;

type StarAlgoConnection = {
  peerId: string;
  peers: string[];
  send: (data: unknown) => void;
  onMessage: (callback: (raw: string, peerId: string, meta?: { local?: boolean }) => void) => void;
  onPeerJoin: (callback: PeerHandler) => void;
  onPeerLeave: (callback: PeerHandler) => void;
  close: () => void;
};

type StarAlgoGlobal = {
  multiplayer: { connect: (room: string) => Promise<StarAlgoConnection> };
};

declare global {
  interface Window {
    StarAlgo?: StarAlgoGlobal;
  }
}

type Envelope = {
  channel: "farhome-v1";
  kind: "hello" | "welcome" | "message" | "leave" | "ping";
  from: string;
  to?: string;
  payload?: string;
  at?: number;
};

export class GameNetwork {
  readonly kind: NetworkKind;
  readonly peerId: string;
  private star: StarAlgoConnection | null = null;
  private channel: BroadcastChannel | null = null;
  private localPeers = new Map<string, number>();
  private messageHandlers = new Set<MessageHandler>();
  private joinHandlers = new Set<PeerHandler>();
  private leaveHandlers = new Set<PeerHandler>();
  private heartbeat: ReturnType<typeof setInterval> | null = null;

  private constructor(kind: NetworkKind, peerId: string) {
    this.kind = kind;
    this.peerId = peerId;
  }

  static async connect(room: string): Promise<GameNetwork> {
    const safeRoom = `farhome-${room.toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 48)}`;
    if (typeof window !== "undefined" && window.StarAlgo?.multiplayer?.connect) {
      try {
        const star = await window.StarAlgo.multiplayer.connect(safeRoom);
        const network = new GameNetwork("staralgo", star.peerId);
        network.star = star;
        star.peers.forEach((id) => network.localPeers.set(id, Date.now()));
        star.onMessage((raw, peerId, meta) => {
          if (meta?.local) return;
          try {
            const data = JSON.parse(raw) as WireMessage;
            if (data && typeof data.type === "string") network.messageHandlers.forEach((handler) => handler(data, peerId));
          } catch {
            // Relay traffic can contain malformed JSON; it is safe to ignore.
          }
        });
        star.onPeerJoin((id) => {
          network.localPeers.set(id, Date.now());
          network.joinHandlers.forEach((handler) => handler(id));
        });
        star.onPeerLeave((id) => {
          network.localPeers.delete(id);
          network.leaveHandlers.forEach((handler) => handler(id));
        });
        return network;
      } catch (error) {
        console.warn("StarAlgo unavailable; using same-browser fallback", error);
      }
    }

    const peerId = `local-${Math.random().toString(36).slice(2, 10)}`;
    const network = new GameNetwork("broadcast", peerId);
    network.channel = new BroadcastChannel(`farhome-${safeRoom}`);
    network.channel.onmessage = (event: MessageEvent<Envelope>) => network.handleLocal(event.data);
    network.postLocal({ channel: "farhome-v1", kind: "hello", from: peerId });
    network.heartbeat = setInterval(() => {
      network.postLocal({ channel: "farhome-v1", kind: "ping", from: peerId, at: Date.now() });
      const now = Date.now();
      network.localPeers.forEach((seen, id) => {
        if (now - seen > 12_000) {
          network.localPeers.delete(id);
          network.leaveHandlers.forEach((handler) => handler(id));
        }
      });
    }, 4_000);
    return network;
  }

  get peers() {
    return [...this.localPeers.keys()];
  }

  private postLocal(envelope: Envelope, to?: string) {
    this.channel?.postMessage(to ? { ...envelope, to } : envelope);
  }

  private handleLocal(envelope: Envelope) {
    if (!envelope || envelope.channel !== "farhome-v1" || envelope.from === this.peerId) return;
    if (envelope.to && envelope.to !== this.peerId) return;
    const known = this.localPeers.has(envelope.from);
    this.localPeers.set(envelope.from, Date.now());
    if (!known && envelope.kind !== "leave") this.joinHandlers.forEach((handler) => handler(envelope.from));
    if (envelope.kind === "hello") {
      this.postLocal({ channel: "farhome-v1", kind: "welcome", from: this.peerId }, envelope.from);
    } else if (envelope.kind === "leave") {
      this.localPeers.delete(envelope.from);
      this.leaveHandlers.forEach((handler) => handler(envelope.from));
    } else if (envelope.kind === "message" && envelope.payload) {
      try {
        const data = JSON.parse(envelope.payload) as WireMessage;
        if (data && typeof data.type === "string") this.messageHandlers.forEach((handler) => handler(data, envelope.from));
      } catch {
        // Ignore malformed local packets as well.
      }
    }
  }

  send(data: WireMessage) {
    if (this.star) this.star.send(data);
    else this.postLocal({ channel: "farhome-v1", kind: "message", from: this.peerId, payload: JSON.stringify(data) });
  }

  onMessage(handler: MessageHandler) {
    this.messageHandlers.add(handler);
  }

  onPeerJoin(handler: PeerHandler) {
    this.joinHandlers.add(handler);
  }

  onPeerLeave(handler: PeerHandler) {
    this.leaveHandlers.add(handler);
  }

  close() {
    if (this.star) this.star.close();
    if (this.channel) {
      this.postLocal({ channel: "farhome-v1", kind: "leave", from: this.peerId });
      this.channel.close();
    }
    if (this.heartbeat) clearInterval(this.heartbeat);
    this.messageHandlers.clear();
    this.joinHandlers.clear();
    this.leaveHandlers.clear();
    this.localPeers.clear();
  }
}
