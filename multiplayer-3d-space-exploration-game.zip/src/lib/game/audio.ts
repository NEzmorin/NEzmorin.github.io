export class GameAudio {
  private context: AudioContext | null = null;

  private ensure() {
    if (!this.context) this.context = new AudioContext();
    if (this.context.state === "suspended") void this.context.resume();
    return this.context;
  }

  play(kind: "pickup" | "laser" | "hit" | "build" | "jump" | "error" | "land") {
    try {
      const context = this.ensure();
      const now = context.currentTime;
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      const settings = {
        pickup: [520, 880, 0.12, "sine"],
        laser: [210, 75, 0.09, "sawtooth"],
        hit: [90, 45, 0.16, "square"],
        build: [140, 420, 0.38, "triangle"],
        jump: [90, 520, 0.55, "sawtooth"],
        error: [150, 110, 0.2, "square"],
        land: [180, 65, 0.5, "triangle"],
      }[kind] as [number, number, number, OscillatorType];
      oscillator.type = settings[3];
      oscillator.frequency.setValueAtTime(settings[0], now);
      oscillator.frequency.exponentialRampToValueAtTime(settings[1], now + settings[2]);
      gain.gain.setValueAtTime(kind === "laser" ? 0.035 : 0.055, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + settings[2]);
      oscillator.connect(gain).connect(context.destination);
      oscillator.start(now);
      oscillator.stop(now + settings[2]);
    } catch {
      // Audio is optional and may be blocked until the first user gesture.
    }
  }

  close() {
    void this.context?.close();
    this.context = null;
  }
}
