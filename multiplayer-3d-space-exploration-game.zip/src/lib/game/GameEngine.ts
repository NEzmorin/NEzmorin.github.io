import * as THREE from "three";
import { GameAudio } from "./audio";
import { EMPTY_INVENTORY, type EngineHooks, type GameOptions, type GameSnapshot, type Inventory, type ItemId, type OverlayKind, type PromptState, type SpawnId, type UpgradeId } from "./engine-types";
import { createAstronaut, createEnemyModel, createRemoteShip, createResource, createShip, type EnemyModelType } from "./models";
import { GameNetwork, type WireMessage } from "./network";
import { generateGalaxy, seeded, systemDistance, type PlanetDefinition, type StarSystem } from "./procedural";

type ResourceNode = {
  id: string;
  type: string;
  label: string;
  group: THREE.Group;
  hp: number;
  maxHp: number;
  amount: number;
};

type Interactable = {
  id: string;
  label: string;
  detail: string;
  group: THREE.Group;
  action: () => void;
};

type Enemy = {
  id: string;
  type: EnemyModelType;
  group: THREE.Group;
  hp: number;
  maxHp: number;
  cooldown: number;
  charge: number;
  stage: number;
  attackCount: number;
  velocity: THREE.Vector3;
  telegraph?: THREE.Mesh;
};

type Projectile = {
  mesh: THREE.Mesh;
  velocity: THREE.Vector3;
  life: number;
  damage: number;
  owner: "player" | "enemy";
};

type RemotePlayer = {
  id: string;
  name: string;
  group: THREE.Group;
  astronaut: THREE.Group;
  ship: THREE.Group;
  targetPosition: THREE.Vector3;
  targetQuaternion: THREE.Quaternion;
  scene: string;
  systemId: string;
  planetId: string | null;
};

const UP = new THREE.Vector3(0, 1, 0);
const RESOURCE_NAMES: Record<string, string> = {
  ore: "Железная руда",
  stone: "Каменная жила",
  scrap: "Груда металлолома",
  crystal: "Резонансный кристалл",
  crate: "Забытый контейнер",
};

export class GameEngine {
  private readonly container: HTMLElement;
  private readonly options: GameOptions;
  private readonly hooks: EngineHooks;
  private readonly renderer: THREE.WebGLRenderer;
  private readonly scene = new THREE.Scene();
  private readonly camera = new THREE.PerspectiveCamera(72, 1, 0.08, 1400);
  private world = new THREE.Group();
  private readonly raycaster = new THREE.Raycaster();
  private readonly audio = new GameAudio();
  private readonly galaxy: StarSystem[];
  private currentSystem = 0;
  private currentPlanet: PlanetDefinition | null = null;
  private sceneKind: "surface" | "space" = "surface";
  private animationFrame = 0;
  private lastFrame = performance.now();
  private elapsed = 0;
  private disposed = false;
  private enabled = true;
  private pointerLocked = false;
  private keys = new Set<string>();
  private firing = false;
  private yaw = 0;
  private pitch = 0;
  private velocity = new THREE.Vector3();
  private verticalVelocity = 0;
  private onGround = true;
  private fireCooldown = 0;
  private scannerCooldown = 0;
  private scanUntil = 0;
  private headlamp: THREE.PointLight;
  private tool = new THREE.Group();
  private resources: ResourceNode[] = [];
  private interactables: Interactable[] = [];
  private enemies: Enemy[] = [];
  private projectiles: Projectile[] = [];
  private colliders: THREE.Box3[] = [];
  private remotes = new Map<string, RemotePlayer>();
  private currentInteract: Interactable | null = null;
  private landingTarget: PlanetDefinition | null = null;
  private mining: { label: string; progress: number } | null = null;
  private shipGroup: THREE.Group | null = null;
  private terrainPhases = [0, 0, 0, 0];
  private depleted = new Set<string>();
  private killedBosses = new Set<string>();
  private network: GameNetwork | null = null;
  private networkKind: GameSnapshot["network"]["kind"];
  private lastSnapshot = 0;
  private lastNetwork = 0;
  private lastPrompt = "";
  private spawnCounter = 0;
  private health = 100;
  private oxygen = 100;
  private fuel = 0;
  private inventory: Inventory = { ...EMPTY_INVENTORY, cannedFood: 1 };
  private parts = { engine: false, hull: false, nav: false };
  private assembled = false;
  private fueled = false;
  private onboard = false;
  private dead = false;
  private level = 1;
  private xp = 0;
  private upgrades: Record<UpgradeId, number> = { engine: 0, tank: 0, laser: 0, shield: 0 };
  private visited = new Set<string>();

  constructor(container: HTMLElement, options: GameOptions, hooks: EngineHooks) {
    this.container = container;
    this.options = options;
    this.hooks = hooks;
    this.galaxy = generateGalaxy(options.seed);
    this.currentPlanet = this.galaxy[0].planets[0];
    this.networkKind = options.roomCode ? "connecting" : "offline";
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.65));
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.domElement.className = "game-canvas";
    container.appendChild(this.renderer.domElement);
    this.camera.rotation.order = "YXZ";
    this.headlamp = new THREE.PointLight("#d5eee1", 0, 24, 1.5);
    this.headlamp.position.set(0, 0.2, 0);
    this.camera.add(this.headlamp);
    this.scene.add(this.camera);
    this.createTool();
    this.bindEvents();
    this.resize();
    this.buildSurface(this.currentPlanet);
    this.animationFrame = requestAnimationFrame(this.animate);
    if (options.roomCode) void this.connect(options.roomCode);
  }

  private createTool() {
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.2, 0.65), new THREE.MeshStandardMaterial({ color: "#4a514b", roughness: 0.65, metalness: 0.75 }));
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.055, 0.5, 8), new THREE.MeshStandardMaterial({ color: "#242b2b", metalness: 0.8, roughness: 0.5 }));
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.03, -0.5);
    const coil = new THREE.Mesh(new THREE.TorusGeometry(0.09, 0.018, 5, 12), new THREE.MeshBasicMaterial({ color: "#b9d883" }));
    coil.position.set(0, 0.03, -0.32);
    this.tool.add(body, barrel, coil);
    this.tool.position.set(0.42, -0.34, -0.72);
    this.tool.rotation.set(-0.08, -0.08, 0);
    this.camera.add(this.tool);
  }

  private async connect(room: string) {
    try {
      this.network = await GameNetwork.connect(room);
      if (this.disposed) {
        this.network.close();
        return;
      }
      this.networkKind = this.network.kind;
      this.network.onMessage((data, peer) => this.handleNetwork(data, peer));
      this.network.onPeerJoin(() => this.hooks.onToast("Связь: новый странник в экспедиции", "good"));
      this.network.onPeerLeave((peer) => this.removeRemote(peer));
      for (const peer of this.network.peers) this.ensureRemote(peer, "Странник");
      this.hooks.onToast(this.network.kind === "staralgo" ? "StarAlgo: канал экспедиции открыт" : "Локальный канал: откройте вторую вкладку", "info");
    } catch {
      this.networkKind = "offline";
      this.hooks.onToast("Сеть недоступна. Продолжаем в одиночку.", "danger");
    }
  }

  private bindEvents() {
    window.addEventListener("resize", this.resize);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("mousemove", this.onMouseMove);
    window.addEventListener("mousedown", this.onMouseDown);
    window.addEventListener("mouseup", this.onMouseUp);
    document.addEventListener("pointerlockchange", this.onPointerLock);
    this.renderer.domElement.addEventListener("click", this.onCanvasClick);
    this.renderer.domElement.addEventListener("contextmenu", this.preventContext);
  }

  private preventContext = (event: Event) => event.preventDefault();
  private onCanvasClick = () => {
    if (this.enabled && !this.pointerLocked) void this.renderer.domElement.requestPointerLock();
  };
  private onPointerLock = () => {
    this.pointerLocked = document.pointerLockElement === this.renderer.domElement;
    if (!this.pointerLocked && this.enabled && !this.dead) {
      this.enabled = false;
      this.keys.clear();
      this.firing = false;
      this.hooks.onOverlay("pause");
    }
  };
  private onMouseMove = (event: MouseEvent) => {
    if (!this.pointerLocked || !this.enabled) return;
    this.yaw -= event.movementX * 0.0021;
    this.pitch -= event.movementY * 0.0021;
    this.pitch = THREE.MathUtils.clamp(this.pitch, -Math.PI / 2 + 0.03, Math.PI / 2 - 0.03);
  };
  private onMouseDown = (event: MouseEvent) => {
    if (event.button === 0 && this.pointerLocked && this.enabled) this.firing = true;
  };
  private onMouseUp = (event: MouseEvent) => {
    if (event.button === 0) this.firing = false;
  };
  private onKeyDown = (event: KeyboardEvent) => {
    if (["Tab", "Space"].includes(event.code)) event.preventDefault();
    if (event.repeat && ["KeyE", "KeyM", "Tab", "KeyB", "KeyR", "Digit1", "Digit2"].includes(event.code)) return;
    if (event.code === "Tab" && this.enabled) return this.openOverlay("inventory");
    if (event.code === "KeyM" && this.enabled) return this.openOverlay("map");
    if (event.code === "KeyB" && this.enabled && this.options.mode === "sandbox") return this.openOverlay("sandbox");
    if (!this.enabled || this.dead) return;
    this.keys.add(event.code);
    if (event.code === "KeyE") this.interact();
    if (event.code === "KeyF") {
      this.headlamp.intensity = this.headlamp.intensity > 0 ? 0 : 18;
      this.hooks.onToast(this.headlamp.intensity ? "Фонарь включён" : "Фонарь выключен");
    }
    if (event.code === "KeyR") this.scan();
    if (event.code === "Digit1") this.useItem("cannedFood");
    if (event.code === "Digit2") this.useItem("medkit");
    if (event.code === "Space" && this.sceneKind === "surface" && this.onGround) {
      this.verticalVelocity = 7.2;
      this.onGround = false;
    }
  };
  private onKeyUp = (event: KeyboardEvent) => this.keys.delete(event.code);
  private resize = () => {
    const width = Math.max(1, this.container.clientWidth);
    const height = Math.max(1, this.container.clientHeight);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private openOverlay(overlay: OverlayKind) {
    this.enabled = false;
    this.keys.clear();
    this.firing = false;
    if (document.pointerLockElement) document.exitPointerLock();
    this.hooks.onOverlay(overlay);
  }

  resume() {
    if (this.dead) return;
    this.enabled = true;
    this.lastFrame = performance.now();
    void this.renderer.domElement.requestPointerLock();
  }

  pause() {
    if (this.enabled) this.openOverlay("pause");
  }

  private clearWorld() {
    this.remotes.forEach((remote) => remote.group.removeFromParent());
    this.scene.remove(this.world);
    this.world.traverse((object) => {
      if (object instanceof THREE.Mesh || object instanceof THREE.Points || object instanceof THREE.Line) {
        object.geometry.dispose();
        const materials = Array.isArray(object.material) ? object.material : [object.material];
        materials.forEach((mat) => mat.dispose());
      }
    });
    this.world = new THREE.Group();
    this.scene.add(this.world);
    this.resources = [];
    this.interactables = [];
    this.enemies = [];
    this.projectiles = [];
    this.colliders = [];
    this.currentInteract = null;
    this.landingTarget = null;
    this.shipGroup = null;
    this.mining = null;
    this.scene.fog = null;
  }

  private addBox(size: [number, number, number], position: [number, number, number], color: string, collide = false) {
    const box = new THREE.Mesh(new THREE.BoxGeometry(...size), new THREE.MeshStandardMaterial({ color, roughness: 0.88, metalness: 0.22 }));
    box.position.set(...position);
    box.castShadow = true;
    box.receiveShadow = true;
    this.world.add(box);
    if (collide) this.colliders.push(new THREE.Box3().setFromObject(box));
    return box;
  }

  private addLights(top: string, ground: string, sun: string) {
    const hemi = new THREE.HemisphereLight(top, ground, 1.7);
    this.world.add(hemi);
    const directional = new THREE.DirectionalLight(sun, 2.6);
    directional.position.set(45, 65, 25);
    directional.castShadow = true;
    directional.shadow.mapSize.set(1024, 1024);
    directional.shadow.camera.left = -70;
    directional.shadow.camera.right = 70;
    directional.shadow.camera.top = 70;
    directional.shadow.camera.bottom = -70;
    directional.shadow.camera.far = 220;
    this.world.add(directional);
  }

  private heightAt(x: number, z: number) {
    const [a, b, c, d] = this.terrainPhases;
    const raw = Math.sin(x * 0.052 + a) * 2.3 + Math.cos(z * 0.061 + b) * 1.8 + Math.sin((x + z) * 0.025 + c) * 3 + Math.cos(Math.hypot(x, z) * 0.08 + d) * 0.7;
    const distance = Math.hypot(x, z);
    const flatRadius = this.currentPlanet?.biome === "home" ? 27 : 20;
    const fade = THREE.MathUtils.smoothstep(distance, flatRadius, flatRadius + 22);
    return raw * fade;
  }

  private buildSurface(planet: PlanetDefinition) {
    this.clearWorld();
    this.sceneKind = "surface";
    this.currentPlanet = planet;
    this.onboard = false;
    this.velocity.set(0, 0, 0);
    this.verticalVelocity = 0;
    const random = seeded(planet.seed, "surface-phases");
    this.terrainPhases = [random() * 8, random() * 8, random() * 8, random() * 8];
    const colors: Record<string, [string, string, string, number]> = {
      home: ["#65745b", "#9ba887", "#071014", 0.94],
      verdant: ["#3d5e46", "#73946d", "#071612", 0.94],
      desert: ["#9a704d", "#d1a06b", "#20130d", 0.92],
      ice: ["#7e9da3", "#c0d8d4", "#07131c", 0.78],
      ash: ["#494547", "#76635b", "#13090a", 0.98],
      ruins: ["#585d59", "#888777", "#101315", 0.96],
      crystal: ["#56516d", "#8b80a1", "#0d0919", 0.9],
    };
    const [groundColor, highColor, skyColor, roughness] = colors[planet.biome];
    this.scene.background = new THREE.Color(skyColor);
    this.scene.fog = new THREE.FogExp2(skyColor, planet.biome === "ash" ? 0.012 : 0.0065);
    this.addLights(highColor, groundColor, planet.biome === "ash" ? "#ef9a70" : "#f1d8a5");
    const terrain = new THREE.PlaneGeometry(270, 270, 90, 90);
    terrain.rotateX(-Math.PI / 2);
    const positions = terrain.attributes.position;
    const vertexColors: number[] = [];
    const low = new THREE.Color(groundColor);
    const high = new THREE.Color(highColor);
    for (let i = 0; i < positions.count; i += 1) {
      const x = positions.getX(i);
      const z = positions.getZ(i);
      const height = this.heightAt(x, z);
      positions.setY(i, height);
      const color = low.clone().lerp(high, THREE.MathUtils.clamp((height + 6) / 14, 0, 1));
      vertexColors.push(color.r, color.g, color.b);
    }
    terrain.setAttribute("color", new THREE.Float32BufferAttribute(vertexColors, 3));
    terrain.computeVertexNormals();
    const ground = new THREE.Mesh(terrain, new THREE.MeshStandardMaterial({ vertexColors: true, roughness }));
    ground.receiveShadow = true;
    this.world.add(ground);
    this.addSky(planet);
    if (planet.biome === "home") this.buildHomestead();
    else this.buildOutpost(planet, random);
    this.camera.position.set(planet.biome === "home" ? -5 : 0, 1.72, planet.biome === "home" ? 0 : 18);
    this.yaw = planet.biome === "home" ? Math.PI : 0;
    this.pitch = 0;
    this.camera.rotation.set(this.pitch, this.yaw, 0);
    this.tool.visible = true;
    this.syncRemoteVisibility();
    if (!this.visited.has(planet.id)) {
      this.visited.add(planet.id);
      if (planet.biome !== "home") {
        this.gainXp(60);
        this.hooks.onToast(`Новая планета: ${planet.name}`, "good");
        this.hooks.onDiscovery({ key: `${this.options.seed}-${planet.id}`, name: planet.name, systemName: this.galaxy[this.currentSystem].name, biome: planet.biome });
      }
    }
  }

  private addSky(planet: PlanetDefinition) {
    const random = seeded(planet.seed, "sky");
    const positions: number[] = [];
    for (let i = 0; i < 750; i += 1) {
      const direction = new THREE.Vector3(random() - 0.5, random() * 0.65 + 0.08, random() - 0.5).normalize().multiplyScalar(420);
      positions.push(direction.x, direction.y, direction.z);
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
    this.world.add(new THREE.Points(geometry, new THREE.PointsMaterial({ color: "#c8d5ca", size: 0.65, transparent: true, opacity: planet.breathable ? 0.35 : 0.85, depthWrite: false })));
    const sun = new THREE.Mesh(new THREE.SphereGeometry(9, 20, 12), new THREE.MeshBasicMaterial({ color: this.galaxy[this.currentSystem].color }));
    sun.position.set(-180, 120, -300);
    this.world.add(sun);
    const haze = new THREE.Mesh(new THREE.SphereGeometry(10.5, 20, 12), new THREE.MeshBasicMaterial({ color: this.galaxy[this.currentSystem].color, transparent: true, opacity: 0.12, side: THREE.BackSide }));
    haze.position.copy(sun.position);
    this.world.add(haze);
  }

  private buildHomestead() {
    const wall = "#5c6258";
    const trim = "#393f3b";
    this.addBox([10, 0.25, 8], [-5, 0, 0], "#48483f");
    this.addBox([10, 3.8, 0.25], [-5, 1.9, -4], wall, true);
    this.addBox([4, 3.8, 0.25], [-8, 1.9, 4], wall, true);
    this.addBox([4, 3.8, 0.25], [-2, 1.9, 4], wall, true);
    this.addBox([0.25, 3.8, 8], [-10, 1.9, 0], wall, true);
    this.addBox([0.25, 3.8, 8], [0, 1.9, 0], wall, true);
    this.addBox([10.5, 0.25, 8.5], [-5, 3.9, 0], trim);
    this.addBox([2.8, 0.55, 1.8], [-8, 0.45, -1.8], "#77715f");
    this.addBox([2.7, 0.12, 1.7], [-8, 0.77, -1.8], "#a09a7c");
    this.addBox([2.2, 0.15, 1.2], [-3, 1.1, -2.4], "#514d40");
    this.addBox([0.15, 1.1, 0.15], [-3.8, 0.55, -2.4], trim);
    this.addBox([0.15, 1.1, 0.15], [-2.2, 0.55, -2.4], trim);
    const lamp = new THREE.PointLight("#d6b577", 6, 12, 2);
    lamp.position.set(-5, 3, 0);
    this.world.add(lamp);
    this.addBox([14, 0.3, 12], [12, 0, 0], "#3f423c");
    this.addBox([14, 5.8, 0.35], [12, 2.9, -6], "#4d514a", true);
    this.addBox([0.35, 5.8, 12], [5, 2.9, 0], "#4d514a", true);
    this.addBox([0.35, 5.8, 12], [19, 2.9, 0], "#4d514a", true);
    this.addBox([4, 5.8, 0.35], [7, 2.9, 6], "#4d514a", true);
    this.addBox([4, 5.8, 0.35], [17, 2.9, 6], "#4d514a", true);
    this.addBox([14.5, 0.3, 12.5], [12, 5.9, 0], trim);
    for (let i = 0; i < 5; i += 1) this.addBox([0.12, 5.3, 0.15], [6 + i * 3, 2.8, -5.75], "#76705e");
    const garageLight = new THREE.PointLight("#d5a565", 9, 18, 2);
    garageLight.position.set(12, 4.6, 1);
    this.world.add(garageLight);
    this.shipGroup = createShip(this.assembled);
    this.shipGroup.position.set(12, 0.15, 0);
    this.shipGroup.rotation.y = -0.35;
    this.world.add(this.shipGroup);
    this.registerInteractable("ship", this.shipGroup, () => this.assembled ? (this.fueled ? "Сесть в корабль" : "Заправить корабль") : "Собрать старый корабль", () => this.assembled ? (this.fueled ? "E · В кабину" : "Нужен топливный элемент") : "Двигатель, обшивка, навигация", () => this.interactShip());
    if (!this.parts.nav) this.spawnPart("nav", "Навигационный блок", [-3, 1.25, -2.4]);
    if (!this.parts.engine) this.spawnPart("engine", "Плазменная катушка", [7, 0.25, -3.8]);
    if (!this.parts.hull) this.spawnPart("hull", "Лист обшивки", [-12, 0.2, 5]);
    if (!this.fueled && this.inventory.fuelCell === 0) this.spawnItem("fuelCell", new THREE.Vector3(17.5, 0.15, 3.8));
    const natural = seeded(this.currentPlanet!.seed, "home-resources");
    for (let i = 0; i < 14; i += 1) {
      const angle = natural() * Math.PI * 2;
      const distance = 32 + natural() * 60;
      this.spawnResource(natural() > 0.7 ? "ore" : "stone", new THREE.Vector3(Math.cos(angle) * distance, 0, Math.sin(angle) * distance), `home-${i}`);
    }
  }

  private spawnPart(part: keyof typeof this.parts, label: string, position: [number, number, number]) {
    const group = createResource("part");
    group.position.set(...position);
    this.world.add(group);
    this.registerInteractable(`part-${part}`, group, () => label, () => "E · Взять деталь", () => {
      this.parts[part] = true;
      group.removeFromParent();
      this.interactables = this.interactables.filter((item) => item.group !== group);
      this.audio.play("pickup");
      this.gainXp(25);
      this.hooks.onToast(`${label}: установлена в инвентарь`, "good");
    });
  }

  private interactShip() {
    if (!this.assembled) {
      const missing = [!this.parts.engine ? "плазменная катушка" : "", !this.parts.hull ? "обшивка" : "", !this.parts.nav ? "навигационный блок" : ""].filter(Boolean);
      if (missing.length) {
        this.audio.play("error");
        this.hooks.onToast(`Не хватает: ${missing.join(", ")}`, "danger");
        return;
      }
      this.assembled = true;
      if (this.shipGroup) {
        const old = this.shipGroup;
        this.shipGroup = createShip(true);
        this.shipGroup.position.copy(old.position);
        this.shipGroup.rotation.copy(old.rotation);
        this.interactables = this.interactables.filter((item) => item.id !== "ship");
        old.removeFromParent();
        this.world.add(this.shipGroup);
        this.registerInteractable("ship", this.shipGroup, () => this.fueled ? "Сесть в корабль" : "Заправить корабль", () => this.fueled ? "E · В кабину" : "Нужен топливный элемент", () => this.interactShip());
      }
      this.gainXp(100);
      this.audio.play("build");
      this.hooks.onToast("Корабль собран. Осталось заправить бак.", "good");
      return;
    }
    if (!this.fueled) {
      if (this.inventory.fuelCell < 1) {
        this.audio.play("error");
        this.hooks.onToast("Топливный элемент лежит где-то в гараже", "danger");
        return;
      }
      this.inventory.fuelCell -= 1;
      this.fuel = this.maxFuel();
      this.fueled = true;
      this.audio.play("build");
      this.gainXp(50);
      this.hooks.onToast("Бак заполнен. Корабль готов к вылету.", "good");
      return;
    }
    this.takeOff();
  }

  private buildOutpost(planet: PlanetDefinition, random: () => number) {
    this.shipGroup = createShip(true);
    this.shipGroup.position.set(0, 0, 7);
    this.shipGroup.scale.setScalar(0.82);
    this.world.add(this.shipGroup);
    this.registerInteractable("ship", this.shipGroup, () => "Вернуться в корабль", () => "E · Взлететь", () => this.takeOff());
    const count = 25 + planet.richness * 6;
    for (let i = 0; i < count; i += 1) {
      const angle = random() * Math.PI * 2;
      const distance = 24 + random() * 95;
      let type = random() > 0.52 ? "ore" : "stone";
      if (planet.biome === "ruins") type = random() > 0.25 ? "scrap" : "ore";
      if (planet.biome === "crystal") type = random() > 0.35 ? "crystal" : "ore";
      if (planet.biome === "ice" && random() > 0.65) type = "crystal";
      if (planet.biome === "ash" && random() > 0.78) type = "crystal";
      this.spawnResource(type, new THREE.Vector3(Math.cos(angle) * distance, 0, Math.sin(angle) * distance), `${planet.id}-r${i}`);
    }
    for (let i = 0; i < 2; i += 1) {
      const angle = random() * Math.PI * 2;
      this.spawnResource("crate", new THREE.Vector3(Math.cos(angle) * (40 + random() * 50), 0, Math.sin(angle) * (40 + random() * 50)), `${planet.id}-crate${i}`);
    }
    if (planet.biome === "ruins") this.buildRuins(random);
    if (planet.biome === "crystal" || planet.biome === "ice") this.buildCrystalFormations(random);
    const enemyCount = planet.danger * 2 + 2;
    for (let i = 0; i < enemyCount; i += 1) {
      const angle = random() * Math.PI * 2;
      const distance = 38 + random() * 75;
      const roll = random();
      const type: EnemyModelType = planet.biome === "ruins" && roll > 0.62 ? "turret" : roll > 0.48 ? "drone" : "crawler";
      this.spawnEnemy(type, new THREE.Vector3(Math.cos(angle) * distance, 0, Math.sin(angle) * distance), `${planet.id}-e${i}`);
    }
    if (planet.boss && !this.killedBosses.has(planet.id)) this.spawnEnemy("boss", new THREE.Vector3(0, 0, -72), `${planet.id}-warden`);
  }

  private buildRuins(random: () => number) {
    for (let i = 0; i < 16; i += 1) {
      const angle = random() * Math.PI * 2;
      const distance = 35 + random() * 75;
      const x = Math.cos(angle) * distance;
      const z = Math.sin(angle) * distance;
      const height = 3 + random() * 13;
      const building = this.addBox([4 + random() * 6, height, 4 + random() * 5], [x, this.heightAt(x, z) + height / 2 - 0.4, z], random() > 0.5 ? "#4d5351" : "#5b5850");
      building.rotation.y = random() * 0.35;
      const strip = new THREE.Mesh(new THREE.BoxGeometry(0.25, height * 0.65, 0.15), new THREE.MeshBasicMaterial({ color: "#8f744d" }));
      strip.position.set(0, 0, -building.scale.z - 2.2);
      building.add(strip);
    }
    for (let i = 0; i < 10; i += 1) {
      const x = (random() - 0.5) * 170;
      const z = (random() - 0.5) * 170;
      if (Math.hypot(x, z) < 25) continue;
      const beam = this.addBox([0.35, 5 + random() * 4, 0.35], [x, this.heightAt(x, z) + 2.5, z], "#393f3e");
      beam.rotation.z = (random() - 0.5) * 0.7;
    }
  }

  private buildCrystalFormations(random: () => number) {
    for (let i = 0; i < 18; i += 1) {
      const angle = random() * Math.PI * 2;
      const distance = 28 + random() * 95;
      const group = createResource("crystal", this.currentPlanet!.accent);
      group.position.set(Math.cos(angle) * distance, 0, Math.sin(angle) * distance);
      group.position.y = this.heightAt(group.position.x, group.position.z);
      group.scale.setScalar(2 + random() * 3);
      this.world.add(group);
    }
  }

  private registerInteractable(id: string, group: THREE.Group, label: () => string, detail: () => string, action: () => void) {
    const item: Interactable = { id, label: label(), detail: detail(), group, action };
    Object.defineProperty(item, "label", { get: label });
    Object.defineProperty(item, "detail", { get: detail });
    group.traverse((child) => { child.userData.interactableId = id; });
    this.interactables.push(item);
  }

  private spawnResource(type: string, position: THREE.Vector3, forcedId?: string, broadcast = false) {
    const id = forcedId || `sandbox-${this.options.playerId}-${this.spawnCounter++}`;
    if (this.depleted.has(id)) return;
    const group = createResource(type, this.currentPlanet?.accent || "#c0b783");
    group.position.copy(position);
    if (this.sceneKind === "surface") group.position.y = this.heightAt(position.x, position.z);
    group.rotation.y = seeded(this.options.seed, id)() * Math.PI * 2;
    this.world.add(group);
    const hp = type === "crystal" ? 70 : type === "crate" ? 35 : 48;
    const node: ResourceNode = { id, type, label: RESOURCE_NAMES[type] || type, group, hp, maxHp: hp, amount: type === "crate" ? 1 : 2 + Math.floor(seeded(this.options.seed, id)() * 3) };
    group.traverse((child) => { child.userData.resourceId = id; });
    this.resources.push(node);
    if (broadcast) this.broadcastSpawn(type as SpawnId, group.position);
  }

  private spawnItem(type: "fuelCell" | "medkit" | "part", position: THREE.Vector3, broadcast = false) {
    const group = createResource(type);
    group.position.copy(position);
    if (this.sceneKind === "surface") group.position.y = this.heightAt(position.x, position.z);
    this.world.add(group);
    const id = `pickup-${type}-${this.spawnCounter++}`;
    const label = type === "fuelCell" ? "Топливный элемент" : type === "medkit" ? "Аптечка" : "Комплект деталей";
    this.registerInteractable(id, group, () => label, () => "E · Подобрать", () => {
      if (type === "part") {
        if (!this.parts.engine) this.parts.engine = true;
        else if (!this.parts.hull) this.parts.hull = true;
        else if (!this.parts.nav) this.parts.nav = true;
        else this.inventory.scrap += 4;
      } else this.inventory[type] += 1;
      group.removeFromParent();
      this.interactables = this.interactables.filter((item) => item.id !== id);
      this.audio.play("pickup");
      this.hooks.onToast(`${label}: получено`, "good");
    });
    if (broadcast) this.broadcastSpawn(type, group.position);
  }

  private spawnEnemy(type: EnemyModelType, position: THREE.Vector3, forcedId?: string, broadcast = false) {
    const id = forcedId || `sandbox-enemy-${this.options.playerId}-${this.spawnCounter++}`;
    const group = createEnemyModel(type);
    group.position.copy(position);
    if (this.sceneKind === "surface") group.position.y = this.heightAt(position.x, position.z);
    group.traverse((child) => { child.userData.enemyId = id; });
    this.world.add(group);
    const maxHp = type === "boss" ? 600 : type === "turret" ? 95 : type === "pirate" ? 110 : type === "drone" ? 65 : 48;
    this.enemies.push({ id, type, group, hp: maxHp, maxHp, cooldown: 1 + Math.random() * 2, charge: 0, stage: 1, attackCount: 0, velocity: new THREE.Vector3() });
    if (broadcast) this.broadcastSpawn(type, group.position);
  }

  private buildSpace(system: StarSystem, fromPlanet?: PlanetDefinition) {
    this.clearWorld();
    this.sceneKind = "space";
    this.currentPlanet = null;
    this.onboard = true;
    this.scene.background = new THREE.Color("#010308");
    this.camera.rotation.set(this.pitch, this.yaw, 0);
    const random = seeded(system.seed, "space");
    const starPositions: number[] = [];
    for (let i = 0; i < 1800; i += 1) {
      const direction = new THREE.Vector3(random() - 0.5, random() - 0.5, random() - 0.5).normalize().multiplyScalar(600 + random() * 500);
      starPositions.push(direction.x, direction.y, direction.z);
    }
    const starGeometry = new THREE.BufferGeometry();
    starGeometry.setAttribute("position", new THREE.Float32BufferAttribute(starPositions, 3));
    this.world.add(new THREE.Points(starGeometry, new THREE.PointsMaterial({ color: "#cbd5d2", size: 1.1, sizeAttenuation: true, depthWrite: false })));
    const star = new THREE.Mesh(new THREE.SphereGeometry(24, 40, 28), new THREE.MeshBasicMaterial({ color: system.color }));
    star.name = "star";
    this.world.add(star);
    const corona = new THREE.Mesh(new THREE.SphereGeometry(28, 32, 20), new THREE.MeshBasicMaterial({ color: system.color, transparent: true, opacity: 0.13, side: THREE.BackSide }));
    star.add(corona);
    const light = new THREE.PointLight(system.color, 4, 0, 0.35);
    this.world.add(light);
    this.world.add(new THREE.AmbientLight("#52606b", 0.38));
    system.planets.forEach((planet, index) => {
      const group = new THREE.Group();
      group.name = `planet-${planet.id}`;
      group.position.set(Math.cos(planet.angle) * planet.orbit, Math.sin(planet.angle * 1.7) * 22, Math.sin(planet.angle) * planet.orbit);
      const sphere = new THREE.Mesh(new THREE.SphereGeometry(planet.radius, 40, 28), new THREE.MeshStandardMaterial({ color: planet.color, roughness: 0.91, metalness: 0.04 }));
      sphere.userData.planetId = planet.id;
      group.add(sphere);
      const atmosphere = new THREE.Mesh(new THREE.SphereGeometry(planet.radius * 1.045, 28, 20), new THREE.MeshBasicMaterial({ color: planet.accent, transparent: true, opacity: planet.breathable ? 0.14 : 0.07, side: THREE.BackSide }));
      group.add(atmosphere);
      if (index % 3 === 2) {
        const ring = new THREE.Mesh(new THREE.RingGeometry(planet.radius * 1.35, planet.radius * 2, 64), new THREE.MeshStandardMaterial({ color: planet.accent, transparent: true, opacity: 0.35, side: THREE.DoubleSide, roughness: 1 }));
        ring.rotation.x = Math.PI / 2.5;
        group.add(ring);
      }
      this.world.add(group);
    });
    for (let i = 0; i < 55; i += 1) {
      const position = new THREE.Vector3((random() - 0.5) * 420, (random() - 0.5) * 150, (random() - 0.5) * 420);
      if (position.length() < 65) continue;
      const asteroid = new THREE.Mesh(new THREE.DodecahedronGeometry(0.8 + random() * 2.7, 0), new THREE.MeshStandardMaterial({ color: "#504f4c", roughness: 0.97 }));
      asteroid.position.copy(position);
      asteroid.rotation.set(random() * 3, random() * 3, random() * 3);
      this.world.add(asteroid);
      if (i % 8 === 0) this.spawnResource("ore", position.clone().add(new THREE.Vector3(2, 0, 0)), `${system.id}-asteroid-${i}`);
    }
    const startPlanet = fromPlanet || system.planets[0];
    const planetGroup = this.world.getObjectByName(`planet-${startPlanet.id}`);
    if (planetGroup) {
      this.camera.position.copy(planetGroup.position).add(new THREE.Vector3(0, 7, startPlanet.radius + 28));
      const direction = planetGroup.position.clone().sub(this.camera.position).normalize();
      this.yaw = Math.atan2(-direction.x, -direction.z);
      this.pitch = Math.asin(direction.y);
    } else this.camera.position.set(0, 20, 180);
    this.velocity.set(0, 0, 0);
    this.tool.visible = false;
    if (!system.home) {
      const pirates = Math.min(4, 1 + Math.floor(this.currentSystem / 5));
      for (let i = 0; i < pirates; i += 1) this.spawnEnemy("pirate", this.camera.position.clone().add(new THREE.Vector3((random() - 0.5) * 150, (random() - 0.5) * 70, -70 - random() * 80)), `${system.id}-pirate-${i}`);
    }
    this.syncRemoteVisibility();
  }

  private takeOff() {
    if (this.fuel < 3) {
      this.audio.play("error");
      this.hooks.onToast("Недостаточно топлива для взлёта", "danger");
      return;
    }
    const planet = this.currentPlanet || this.galaxy[this.currentSystem].planets[0];
    this.fuel = Math.max(0, this.fuel - 2);
    this.fueled = true;
    this.audio.play("jump");
    this.buildSpace(this.galaxy[this.currentSystem], planet);
    this.hooks.onToast("Орбита достигнута. M · карта звёзд", "good");
  }

  landOnPlanet(id: string) {
    if (this.sceneKind !== "space") return;
    const planet = this.galaxy[this.currentSystem].planets.find((item) => item.id === id);
    if (!planet || this.landingTarget?.id !== id) {
      this.hooks.onToast("Сблизьтесь с планетой для посадки", "danger");
      return;
    }
    this.audio.play("land");
    this.buildSurface(planet);
  }

  jumpToSystem(id: string) {
    if (this.sceneKind !== "space") {
      this.hooks.onToast("Прыжок доступен только из кабины корабля", "danger");
      return false;
    }
    const index = this.galaxy.findIndex((system) => system.id === id);
    if (index < 0 || index === this.currentSystem) return false;
    const cost = Math.max(2, Math.ceil(systemDistance(this.galaxy[this.currentSystem], this.galaxy[index]) / 11));
    if (this.fuel < cost) {
      this.audio.play("error");
      this.hooks.onToast(`Для прыжка нужно ${cost} ед. топлива`, "danger");
      return false;
    }
    this.fuel -= cost;
    this.currentSystem = index;
    this.audio.play("jump");
    this.buildSpace(this.galaxy[index]);
    this.gainXp(35 + index * 2);
    this.hooks.onToast(`Прыжок завершён: ${this.galaxy[index].name} · −${cost} топлива`, "good");
    return true;
  }

  private interact() {
    if (this.sceneKind === "surface" && this.currentInteract) this.currentInteract.action();
    else if (this.sceneKind === "space" && this.landingTarget) this.landOnPlanet(this.landingTarget.id);
  }

  private updateSurface(dt: number) {
    const forward = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const right = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    const wish = new THREE.Vector3();
    if (this.keys.has("KeyW")) wish.add(forward);
    if (this.keys.has("KeyS")) wish.sub(forward);
    if (this.keys.has("KeyD")) wish.add(right);
    if (this.keys.has("KeyA")) wish.sub(right);
    if (wish.lengthSq() > 0) wish.normalize();
    const speed = this.keys.has("ShiftLeft") || this.keys.has("ShiftRight") ? 9.2 : 5.8;
    this.velocity.x = THREE.MathUtils.damp(this.velocity.x, wish.x * speed, 12, dt);
    this.velocity.z = THREE.MathUtils.damp(this.velocity.z, wish.z * speed, 12, dt);
    const nextX = THREE.MathUtils.clamp(this.camera.position.x + this.velocity.x * dt, -131, 131);
    const nextZ = THREE.MathUtils.clamp(this.camera.position.z + this.velocity.z * dt, -131, 131);
    const test = new THREE.Vector3(nextX, 1, this.camera.position.z);
    if (!this.colliders.some((box) => box.clone().expandByScalar(0.32).containsPoint(test))) this.camera.position.x = nextX;
    test.set(this.camera.position.x, 1, nextZ);
    if (!this.colliders.some((box) => box.clone().expandByScalar(0.32).containsPoint(test))) this.camera.position.z = nextZ;
    const ground = this.heightAt(this.camera.position.x, this.camera.position.z) + 1.72;
    if (!this.onGround) {
      this.verticalVelocity -= 18 * (this.currentPlanet?.gravity || 1) * dt;
      this.camera.position.y += this.verticalVelocity * dt;
      if (this.camera.position.y <= ground) {
        if (this.verticalVelocity < -12) this.damage(Math.abs(this.verticalVelocity) * 1.3);
        this.camera.position.y = ground;
        this.verticalVelocity = 0;
        this.onGround = true;
      }
    } else this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, ground, 18, dt);
    this.camera.rotation.set(this.pitch, this.yaw, 0);
    const nearShip = this.shipGroup && this.camera.position.distanceTo(this.shipGroup.position) < 9;
    if (!this.currentPlanet?.breathable && !nearShip) this.oxygen = Math.max(0, this.oxygen - dt * 1.15);
    else this.oxygen = Math.min(100, this.oxygen + dt * 9);
    if (this.oxygen <= 0) this.damage(dt * 7);
    if (nearShip) this.health = Math.min(this.maxHealth(), this.health + dt * 0.8);
    this.updateMining(dt);
  }

  private updateSpace(dt: number) {
    const forward = new THREE.Vector3(0, 0, -1).applyEuler(this.camera.rotation);
    const right = new THREE.Vector3(1, 0, 0).applyEuler(this.camera.rotation);
    const up = UP.clone().applyQuaternion(this.camera.quaternion);
    const thrust = new THREE.Vector3();
    if (this.keys.has("KeyW")) thrust.add(forward);
    if (this.keys.has("KeyS")) thrust.sub(forward);
    if (this.keys.has("KeyD")) thrust.add(right);
    if (this.keys.has("KeyA")) thrust.sub(right);
    if (this.keys.has("Space")) thrust.add(up);
    if (this.keys.has("ControlLeft") || this.keys.has("ControlRight")) thrust.sub(up);
    const boosting = (this.keys.has("ShiftLeft") || this.keys.has("ShiftRight")) && this.fuel > 0;
    if (thrust.lengthSq() && this.fuel > 0) {
      thrust.normalize();
      this.velocity.addScaledVector(thrust, (boosting ? 34 : 17) * dt);
      this.fuel = Math.max(0, this.fuel - dt * (boosting ? 0.65 : 0.16));
    }
    const maxSpeed = (42 + this.upgrades.engine * 18) * (boosting ? 1.45 : 1);
    if (this.velocity.length() > maxSpeed) this.velocity.setLength(maxSpeed);
    this.velocity.multiplyScalar(Math.pow(0.993, dt * 60));
    this.camera.position.addScaledVector(this.velocity, dt);
    this.camera.rotation.set(this.pitch, this.yaw, 0);
    if (this.camera.position.length() < 34) {
      this.damage(dt * 28);
      this.velocity.add(this.camera.position.clone().normalize().multiplyScalar(dt * 25));
    }
    if (this.firing && this.fireCooldown <= 0) this.fireLaser();
    this.landingTarget = null;
    let nearest = Infinity;
    this.galaxy[this.currentSystem].planets.forEach((planet) => {
      const object = this.world.getObjectByName(`planet-${planet.id}`);
      if (!object) return;
      const distance = this.camera.position.distanceTo(object.position) - planet.radius;
      if (distance < 22 && distance < nearest) {
        nearest = distance;
        this.landingTarget = planet;
      }
    });
  }

  private updateMining(dt: number) {
    this.mining = null;
    this.raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);
    this.raycaster.far = 4.8;
    const hit = this.raycaster.intersectObjects(this.world.children, true)[0];
    if (!hit) return;
    let object: THREE.Object3D | null = hit.object;
    let resourceId: string | undefined;
    let enemyId: string | undefined;
    while (object) {
      resourceId ||= object.userData.resourceId as string | undefined;
      enemyId ||= object.userData.enemyId as string | undefined;
      object = object.parent;
    }
    const resource = resourceId ? this.resources.find((item) => item.id === resourceId) : null;
    const enemy = enemyId ? this.enemies.find((item) => item.id === enemyId) : null;
    if (resource) this.mining = { label: resource.label, progress: 1 - resource.hp / resource.maxHp };
    if (enemy) this.mining = { label: enemy.type === "boss" ? "Страж Пустоты" : "Цель", progress: 1 - enemy.hp / enemy.maxHp };
    if (!this.firing || (!resource && !enemy)) return;
    const damage = (25 + this.upgrades.laser * 12 + (this.level - 1) * 2) * dt;
    this.tool.rotation.x = -0.08 + Math.sin(this.elapsed * 45) * 0.015;
    if (this.fireCooldown <= 0) {
      this.audio.play("laser");
      this.fireCooldown = 0.16;
    }
    if (resource) {
      resource.hp -= damage;
      if (resource.hp <= 0) this.depleteResource(resource);
    } else if (enemy) {
      enemy.hp -= damage * (enemy.type === "boss" && enemy.stage === 3 ? 1.45 : 1);
      if (enemy.hp <= 0) this.killEnemy(enemy);
    }
  }

  private depleteResource(resource: ResourceNode) {
    resource.group.removeFromParent();
    this.resources = this.resources.filter((item) => item !== resource);
    this.depleted.add(resource.id);
    if (resource.type === "crate") {
      this.inventory.scrap += 2 + Math.floor(Math.random() * 4);
      if (Math.random() > 0.5) this.inventory.fuelCell += 1;
      else this.inventory.medkit += 1;
    } else if (resource.type in this.inventory) this.inventory[resource.type as ItemId] += resource.amount * (this.currentPlanet?.richness || 1);
    this.gainXp(resource.type === "crystal" ? 24 : 12);
    this.audio.play("pickup");
    this.hooks.onToast(resource.type === "crate" ? "Контейнер вскрыт: припасы в инвентаре" : `Добыто: ${resource.label} ×${resource.amount * (this.currentPlanet?.richness || 1)}`, "good");
    this.network?.send({ type: "resource", id: resource.id, planetId: this.currentPlanet?.id || this.galaxy[this.currentSystem].id });
  }

  private fireLaser() {
    this.fireCooldown = Math.max(0.09, 0.22 - this.upgrades.laser * 0.035);
    this.audio.play("laser");
    const direction = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion).normalize();
    const laser = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 2.8), new THREE.MeshBasicMaterial({ color: "#b8e795" }));
    laser.position.copy(this.camera.position).addScaledVector(direction, 1.4);
    laser.quaternion.copy(this.camera.quaternion);
    this.world.add(laser);
    this.projectiles.push({ mesh: laser, velocity: direction.multiplyScalar(150), life: 2.2, damage: 28 + this.upgrades.laser * 13, owner: "player" });
  }

  private enemyProjectile(enemy: Enemy, direction: THREE.Vector3, speed = 22, damage = 12, originHeight?: number) {
    const color = enemy.type === "boss" ? "#ef704c" : "#e3ad5e";
    const shot = new THREE.Mesh(new THREE.SphereGeometry(enemy.type === "boss" ? 0.3 : 0.16, 8, 6), new THREE.MeshBasicMaterial({ color }));
    const height = originHeight ?? (enemy.type === "boss" ? 3.5 : enemy.type === "crawler" ? 0.7 : 1);
    shot.position.copy(enemy.group.position).add(new THREE.Vector3(0, height, 0));
    this.world.add(shot);
    this.projectiles.push({ mesh: shot, velocity: direction.normalize().multiplyScalar(speed), life: 5, damage, owner: "enemy" });
  }

  private aimedShot(enemy: Enemy, speed = 24, damage = 12, spread = 0) {
    const origin = enemy.group.position.clone().add(new THREE.Vector3(0, enemy.type === "boss" ? 3.5 : 1, 0));
    const direction = this.camera.position.clone().sub(origin).normalize();
    if (spread) direction.add(new THREE.Vector3((Math.random() - 0.5) * spread, (Math.random() - 0.5) * spread, (Math.random() - 0.5) * spread));
    this.enemyProjectile(enemy, direction, speed, damage);
  }

  private updateEnemies(dt: number) {
    for (const enemy of [...this.enemies]) {
      const toPlayer = this.camera.position.clone().sub(enemy.group.position);
      const distance = toPlayer.length();
      enemy.cooldown -= dt;
      if (enemy.type === "boss") {
        this.updateBoss(enemy, dt, distance, toPlayer);
        continue;
      }
      if (distance > (enemy.type === "pirate" ? 230 : 60)) continue;
      if (enemy.type === "crawler") {
        if (distance > 2.1) {
          const direction = toPlayer.setY(0).normalize();
          enemy.group.position.addScaledVector(direction, dt * (2.7 + (this.currentPlanet?.danger || 1) * 0.18));
          enemy.group.position.y = this.heightAt(enemy.group.position.x, enemy.group.position.z);
          enemy.group.lookAt(this.camera.position.x, enemy.group.position.y, this.camera.position.z);
        } else if (enemy.cooldown <= 0) {
          this.damage(9 + (this.currentPlanet?.danger || 1) * 1.5);
          enemy.cooldown = 1.15;
          this.audio.play("hit");
        }
      } else if (enemy.type === "drone") {
        const targetY = this.heightAt(enemy.group.position.x, enemy.group.position.z) + 4 + Math.sin(this.elapsed * 2 + enemy.group.position.x) * 0.5;
        enemy.group.position.y = THREE.MathUtils.damp(enemy.group.position.y, targetY, 5, dt);
        if (distance > 14) enemy.group.position.addScaledVector(toPlayer.normalize(), dt * 3.2);
        else if (distance < 8) enemy.group.position.addScaledVector(toPlayer.normalize(), -dt * 2.2);
        enemy.group.position.add(new THREE.Vector3(Math.sin(this.elapsed + enemy.group.position.x) * dt, 0, Math.cos(this.elapsed + enemy.group.position.z) * dt));
        enemy.group.lookAt(this.camera.position);
      } else if (enemy.type === "turret") {
        const head = enemy.group.getObjectByName("head");
        if (head) head.lookAt(this.camera.position);
      } else if (enemy.type === "pirate") {
        if (distance > 45) enemy.group.position.addScaledVector(toPlayer.normalize(), dt * 13);
        else enemy.group.position.addScaledVector(new THREE.Vector3(-toPlayer.z, toPlayer.y * 0.1, toPlayer.x).normalize(), dt * 8);
        enemy.group.lookAt(this.camera.position);
      }
      if (enemy.type !== "crawler") {
        if (enemy.charge > 0) {
          enemy.charge -= dt;
          const scale = 1 + Math.sin(this.elapsed * 28) * 0.06;
          enemy.group.scale.setScalar(scale);
          if (enemy.charge <= 0) {
            enemy.group.scale.setScalar(1);
            this.aimedShot(enemy, enemy.type === "pirate" ? 42 : 25, enemy.type === "turret" ? 16 : 11, enemy.type === "drone" ? 0.05 : 0.02);
            enemy.cooldown = enemy.type === "turret" ? 2.4 : enemy.type === "pirate" ? 1.5 : 2.8;
          }
        } else if (enemy.cooldown <= 0 && distance < (enemy.type === "pirate" ? 130 : 42)) {
          enemy.charge = enemy.type === "turret" ? 1.1 : 0.65;
        }
      }
    }
  }

  private updateBoss(enemy: Enemy, dt: number, distance: number, toPlayer: THREE.Vector3) {
    if (distance > 72) return;
    const ratio = enemy.hp / enemy.maxHp;
    const newStage = ratio > 0.66 ? 1 : ratio > 0.33 ? 2 : 3;
    if (newStage !== enemy.stage) {
      enemy.stage = newStage;
      enemy.cooldown = 1.5;
      this.hooks.onToast(newStage === 2 ? "Страж: фаза II · ракетный рой" : "Страж: фаза III · ядро раскрыто", "danger");
      for (let i = 0; i < 2; i += 1) this.spawnEnemy("drone", enemy.group.position.clone().add(new THREE.Vector3(i ? 8 : -8, 2, 5)));
    }
    const halo = enemy.group.getObjectByName("boss-halo");
    if (halo) {
      halo.rotation.z += dt * (0.5 + enemy.stage * 0.4);
      halo.scale.setScalar(1 + Math.sin(this.elapsed * 5) * 0.08);
    }
    if (distance > 18) enemy.group.position.addScaledVector(toPlayer.setY(0).normalize(), dt * (1.1 + enemy.stage * 0.55));
    enemy.group.position.y = this.heightAt(enemy.group.position.x, enemy.group.position.z);
    enemy.group.lookAt(this.camera.position.x, enemy.group.position.y, this.camera.position.z);
    if (enemy.charge > 0) {
      enemy.charge -= dt;
      if (enemy.telegraph) {
        const progress = 1 - enemy.charge / (enemy.stage === 1 ? 1.5 : 1.15);
        enemy.telegraph.position.set(enemy.group.position.x, enemy.group.position.y + 0.12, enemy.group.position.z);
        enemy.telegraph.scale.setScalar(1 + progress * (enemy.stage === 2 ? 4 : 12));
        (enemy.telegraph.material as THREE.MeshBasicMaterial).opacity = 0.65 * (1 - progress * 0.5);
      }
      if (enemy.charge <= 0) {
        if (enemy.telegraph) {
          const shockwave = enemy.stage === 1 || (enemy.stage === 3 && enemy.attackCount % 2 === 0);
          if (shockwave && distance < 18) this.damage(30);
          enemy.telegraph.removeFromParent();
          enemy.telegraph = undefined;
        }
        if (enemy.stage === 2) {
          for (let i = 0; i < 10; i += 1) {
            const angle = (i / 10) * Math.PI * 2;
            this.enemyProjectile(enemy, new THREE.Vector3(Math.cos(angle), 0, Math.sin(angle)), 17, 13, 1.65);
          }
          this.aimedShot(enemy, 27, 15, 0.12);
        } else if (enemy.stage === 3) {
          for (let i = 0; i < 5; i += 1) this.aimedShot(enemy, 32, 14, 0.13);
        }
        enemy.attackCount += 1;
        enemy.cooldown = enemy.stage === 1 ? 3.8 : enemy.stage === 2 ? 3.2 : 2.2;
      }
    } else if (enemy.cooldown <= 0 && distance < 55) {
      enemy.charge = enemy.stage === 1 ? 1.5 : 1.15;
      if (enemy.stage === 1 || enemy.stage === 2 || (enemy.stage === 3 && enemy.attackCount % 2 === 0)) {
        const ring = new THREE.Mesh(new THREE.RingGeometry(1.2, 1.5, 48), new THREE.MeshBasicMaterial({ color: enemy.stage === 2 ? "#e0b45f" : "#f06f4b", transparent: true, opacity: 0.65, side: THREE.DoubleSide, depthWrite: false }));
        ring.rotation.x = -Math.PI / 2;
        ring.position.copy(enemy.group.position).add(new THREE.Vector3(0, 0.12, 0));
        this.world.add(ring);
        enemy.telegraph = ring;
      }
    }
  }

  private updateProjectiles(dt: number) {
    for (const projectile of [...this.projectiles]) {
      projectile.life -= dt;
      projectile.mesh.position.addScaledVector(projectile.velocity, dt);
      let hit = false;
      if (projectile.owner === "enemy") {
        if (projectile.mesh.position.distanceTo(this.camera.position) < (this.sceneKind === "space" ? 2.4 : 0.75)) {
          this.damage(projectile.damage);
          hit = true;
        }
      } else {
        for (const enemy of [...this.enemies]) {
          const radius = enemy.type === "boss" ? 3.4 : enemy.type === "pirate" ? 2 : 1.3;
          const center = enemy.group.position.clone().add(new THREE.Vector3(0, enemy.type === "boss" ? 3 : 0, 0));
          if (projectile.mesh.position.distanceTo(center) < radius) {
            enemy.hp -= projectile.damage * (enemy.type === "boss" && enemy.stage === 3 ? 1.45 : 1);
            if (enemy.hp <= 0) this.killEnemy(enemy);
            hit = true;
            break;
          }
        }
        if (!hit) {
          for (const resource of [...this.resources]) {
            if (projectile.mesh.position.distanceTo(resource.group.position) < 2) {
              resource.hp -= projectile.damage;
              if (resource.hp <= 0) this.depleteResource(resource);
              hit = true;
              break;
            }
          }
        }
      }
      if (hit || projectile.life <= 0) {
        projectile.mesh.removeFromParent();
        this.projectiles = this.projectiles.filter((item) => item !== projectile);
      }
    }
  }

  private killEnemy(enemy: Enemy) {
    enemy.group.removeFromParent();
    enemy.telegraph?.removeFromParent();
    this.enemies = this.enemies.filter((item) => item !== enemy);
    this.audio.play("pickup");
    if (enemy.type === "boss") {
      this.inventory.crystal += 10;
      this.inventory.scrap += 14;
      if (this.currentPlanet) this.killedBosses.add(this.currentPlanet.id);
      this.gainXp(350);
      this.hooks.onToast("Страж уничтожен: ядро и редкие сплавы получены", "good");
    } else {
      this.inventory.scrap += enemy.type === "pirate" ? 4 : 1;
      if (enemy.type === "pirate") this.inventory.fuelCell += 1;
      this.gainXp(enemy.type === "pirate" ? 70 : 30);
    }
  }

  private updatePrompt() {
    let prompt: PromptState = null;
    this.currentInteract = null;
    if (this.sceneKind === "surface") {
      this.raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);
      this.raycaster.far = 4.3;
      const hits = this.raycaster.intersectObjects(this.world.children, true);
      for (const hit of hits) {
        let object: THREE.Object3D | null = hit.object;
        let id: string | undefined;
        while (object && !id) {
          id = object.userData.interactableId as string | undefined;
          object = object.parent;
        }
        if (id) {
          const interactable = this.interactables.find((item) => item.id === id);
          if (interactable) {
            this.currentInteract = interactable;
            prompt = { key: "E", title: interactable.label, detail: interactable.detail };
          }
          break;
        }
        if (hit.distance < 4.3 && !id) break;
      }
    } else if (this.landingTarget) {
      prompt = { key: "E", title: `Посадка: ${this.landingTarget.name}`, detail: `${this.landingTarget.description} Угроза ${this.landingTarget.danger}/5` };
    }
    const signature = JSON.stringify(prompt);
    if (signature !== this.lastPrompt) {
      this.lastPrompt = signature;
      this.hooks.onPrompt(prompt);
    }
  }

  private damage(amount: number) {
    if (this.dead) return;
    const shieldReduction = this.upgrades.shield * 0.09;
    this.health = Math.max(0, this.health - amount * (1 - shieldReduction));
    if (this.health <= 0) {
      this.dead = true;
      this.enabled = false;
      this.firing = false;
      if (document.pointerLockElement) document.exitPointerLock();
      this.hooks.onOverlay("death");
    }
  }

  respawn() {
    for (const key of ["ore", "stone", "scrap", "crystal"] as ItemId[]) this.inventory[key] = Math.floor(this.inventory[key] * 0.8);
    this.health = this.maxHealth();
    this.oxygen = 100;
    this.dead = false;
    this.buildSurface(this.currentPlanet || this.galaxy[this.currentSystem].planets[0]);
    this.enabled = true;
    this.hooks.onToast("Аварийный контур восстановил скафандр. 20% ресурсов потеряно.", "info");
  }

  private maxFuel() {
    return 100 + this.upgrades.tank * 55;
  }
  private maxHealth() {
    return 100 + this.upgrades.shield * 25;
  }

  private gainXp(amount: number) {
    this.xp += Math.round(amount);
    let next = 100 + (this.level - 1) * 85;
    while (this.xp >= next) {
      this.xp -= next;
      this.level += 1;
      this.health = this.maxHealth();
      this.hooks.onToast(`Уровень ${this.level}: характеристики инструмента повышены`, "good");
      next = 100 + (this.level - 1) * 85;
    }
  }

  private scan() {
    if (this.scannerCooldown > 0) {
      this.hooks.onToast(`Сканер перезаряжается: ${Math.ceil(this.scannerCooldown)} с`);
      return;
    }
    this.scannerCooldown = Math.max(7, 14 - this.level);
    this.scanUntil = this.elapsed + 6;
    this.audio.play("pickup");
    this.hooks.onToast(`Сканирование: ${this.resources.length} объектов, ${this.enemies.length} угроз`, "info");
  }

  useItem(item: ItemId) {
    if (this.inventory[item] <= 0) {
      this.audio.play("error");
      this.hooks.onToast("Предмет отсутствует в инвентаре", "danger");
      return false;
    }
    if (item === "cannedFood" || item === "medkit") {
      if (this.health >= this.maxHealth()) {
        this.hooks.onToast("Здоровье уже восстановлено");
        return false;
      }
      this.health = Math.min(this.maxHealth(), this.health + (item === "medkit" ? 60 : 30));
      this.oxygen = Math.min(100, this.oxygen + 15);
    } else if (item === "fuelCell") {
      if (this.sceneKind !== "space") {
        this.hooks.onToast("Топливный элемент используется в кабине или при заправке", "info");
        return false;
      }
      if (this.fuel >= this.maxFuel() - 1) {
        this.hooks.onToast("Бак уже полон");
        return false;
      }
      this.fuel = Math.min(this.maxFuel(), this.fuel + 45);
    } else {
      this.hooks.onToast("Этот ресурс нужен для улучшений", "info");
      return false;
    }
    this.inventory[item] -= 1;
    this.audio.play("pickup");
    return true;
  }

  private recipe(id: UpgradeId) {
    const level = this.upgrades[id];
    const scale = level + 1;
    if (id === "engine") return { ore: 7 * scale, stone: 0, scrap: 4 * scale, crystal: level * 3 };
    if (id === "tank") return { ore: 5 * scale, stone: 4 * scale, scrap: 3 * scale, crystal: level * 2 };
    if (id === "laser") return { ore: 6 * scale, stone: 0, scrap: 2 * scale, crystal: 2 * scale };
    return { ore: 2 * scale, stone: 0, scrap: 7 * scale, crystal: 3 * scale };
  }

  getRecipe(id: UpgradeId) {
    return this.recipe(id);
  }

  craft(id: UpgradeId) {
    const max = id === "laser" ? 3 : 2;
    if (this.upgrades[id] >= max) {
      this.hooks.onToast("Модуль уже максимального уровня");
      return false;
    }
    if (!this.canCraft()) {
      this.audio.play("error");
      this.hooks.onToast("Улучшения устанавливаются только у корабля", "danger");
      return false;
    }
    const recipe = this.recipe(id);
    const enough = (Object.entries(recipe) as Array<[ItemId, number]>).every(([item, amount]) => this.inventory[item] >= amount);
    if (!enough) {
      this.audio.play("error");
      this.hooks.onToast("Недостаточно ресурсов для модуля", "danger");
      return false;
    }
    (Object.entries(recipe) as Array<[ItemId, number]>).forEach(([item, amount]) => { this.inventory[item] -= amount; });
    this.upgrades[id] += 1;
    if (id === "tank") this.fuel += 55;
    if (id === "shield") this.health += 25;
    this.audio.play("build");
    this.gainXp(40);
    this.hooks.onToast("Модуль установлен и уже работает", "good");
    return true;
  }

  private canCraft() {
    return this.sceneKind === "space" || Boolean(this.shipGroup && this.camera.position.distanceTo(this.shipGroup.position) < 11);
  }

  spawnSandbox(type: SpawnId, network = true, suppliedPosition?: number[]) {
    if (this.options.mode !== "sandbox") return;
    const direction = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
    const position = suppliedPosition ? new THREE.Vector3(...suppliedPosition) : this.camera.position.clone().addScaledVector(direction, this.sceneKind === "space" ? 14 : 6);
    if (this.sceneKind === "surface") position.y = this.heightAt(position.x, position.z);
    if (["crawler", "drone", "turret", "boss", "pirate"].includes(type)) {
      if (this.sceneKind === "space" && type !== "pirate") {
        this.hooks.onToast("Наземная угроза может быть создана только на поверхности", "info");
        return;
      }
      this.spawnEnemy(type as EnemyModelType, position, undefined, network);
    } else if (["fuelCell", "medkit", "part"].includes(type)) {
      if (this.sceneKind === "space") {
        this.inventory[type as ItemId] += 1;
        this.hooks.onToast("Груз доставлен прямо в трюм", "good");
      } else this.spawnItem(type as "fuelCell" | "medkit" | "part", position, network);
    } else this.spawnResource(type, position, undefined, network);
    this.audio.play("build");
  }

  private broadcastSpawn(type: SpawnId, position: THREE.Vector3) {
    this.network?.send({ type: "spawn", spawnId: type, position: position.toArray(), scene: this.sceneKind, systemId: this.galaxy[this.currentSystem].id, planetId: this.currentPlanet?.id || null });
  }

  sendChat(message: string) {
    const text = message.trim().slice(0, 160);
    if (!text || !this.network) return;
    this.network.send({ type: "chat", text, name: this.options.playerName });
  }

  private handleNetwork(data: WireMessage, peer: string) {
    if (data.type === "state") {
      const position = data.position as number[];
      const quaternion = data.quaternion as number[];
      if (!Array.isArray(position) || !Array.isArray(quaternion)) return;
      const remote = this.ensureRemote(peer, typeof data.name === "string" ? data.name : "Странник");
      remote.targetPosition.fromArray(position);
      remote.targetQuaternion.fromArray(quaternion);
      remote.scene = String(data.scene || "surface");
      remote.systemId = String(data.systemId || "home");
      remote.planetId = typeof data.planetId === "string" ? data.planetId : null;
      remote.astronaut.visible = remote.scene === "surface";
      remote.ship.visible = remote.scene === "space";
      this.syncRemoteVisibility();
    } else if (data.type === "resource" && typeof data.id === "string") {
      this.depleted.add(data.id);
      const resource = this.resources.find((item) => item.id === data.id);
      if (resource) {
        resource.group.removeFromParent();
        this.resources = this.resources.filter((item) => item !== resource);
      }
    } else if (data.type === "spawn" && typeof data.spawnId === "string") {
      if (data.scene === this.sceneKind && data.systemId === this.galaxy[this.currentSystem].id && (data.planetId || null) === (this.currentPlanet?.id || null)) {
        this.spawnSandbox(data.spawnId as SpawnId, false, data.position as number[]);
      }
    } else if (data.type === "chat" && typeof data.text === "string") {
      this.hooks.onToast(`${String(data.name || "Странник")}: ${data.text.slice(0, 160)}`, "info");
    }
  }

  private ensureRemote(id: string, name: string) {
    let remote = this.remotes.get(id);
    if (!remote) {
      const group = new THREE.Group();
      const astronaut = createAstronaut(name);
      astronaut.position.y = -1.72;
      const ship = createRemoteShip();
      ship.visible = false;
      group.add(astronaut, ship);
      remote = { id, name, group, astronaut, ship, targetPosition: new THREE.Vector3(), targetQuaternion: new THREE.Quaternion(), scene: "surface", systemId: "home", planetId: "home-0" };
      this.remotes.set(id, remote);
    }
    return remote;
  }

  private removeRemote(id: string) {
    const remote = this.remotes.get(id);
    remote?.group.removeFromParent();
    this.remotes.delete(id);
  }

  private syncRemoteVisibility() {
    this.remotes.forEach((remote) => {
      const visible = remote.scene === this.sceneKind && remote.systemId === this.galaxy[this.currentSystem].id && (remote.scene === "space" || remote.planetId === this.currentPlanet?.id);
      if (visible && remote.group.parent !== this.world) this.world.add(remote.group);
      if (!visible) remote.group.removeFromParent();
    });
  }

  private sendNetworkState() {
    if (!this.network) return;
    this.network.send({
      type: "state",
      name: this.options.playerName,
      scene: this.sceneKind,
      systemId: this.galaxy[this.currentSystem].id,
      planetId: this.currentPlanet?.id || null,
      position: this.camera.position.toArray().map((value) => Math.round(value * 100) / 100),
      quaternion: this.camera.quaternion.toArray().map((value) => Math.round(value * 1000) / 1000),
    });
  }

  private updateRemotes(dt: number) {
    this.remotes.forEach((remote) => {
      remote.group.position.lerp(remote.targetPosition, 1 - Math.exp(-dt * 12));
      remote.group.quaternion.slerp(remote.targetQuaternion, 1 - Math.exp(-dt * 12));
    });
  }

  private objective() {
    if (this.currentPlanet?.biome === "home") {
      const count = Object.values(this.parts).filter(Boolean).length;
      if (count < 3) return `Обыщите дом и гараж · детали ${count}/3`;
      if (!this.assembled) return "Соберите ржавый корабль в космогараже";
      if (!this.fueled) return "Найдите топливный элемент и заправьте корабль";
      return "Сядьте в корабль и покиньте родную систему";
    }
    if (this.sceneKind === "space") return "Исследуйте планеты · E для посадки · M для прыжка";
    if (this.currentPlanet?.boss && !this.killedBosses.has(this.currentPlanet.id)) return "Сигнал Стража в глубине планеты · припасы и улучшения помогут";
    if (this.currentPlanet?.biome === "ruins") return "Разбирайте городской лом · остерегайтесь турелей";
    return "Добывайте ресурсы и возвращайтесь к кораблю";
  }

  private snapshot(): GameSnapshot {
    const activeBoss = this.enemies.find((enemy) => enemy.type === "boss" && enemy.group.position.distanceTo(this.camera.position) < 80);
    return {
      scene: this.sceneKind,
      health: this.health,
      maxHealth: this.maxHealth(),
      oxygen: this.oxygen,
      fuel: this.fuel,
      maxFuel: this.maxFuel(),
      speed: this.velocity.length(),
      inventory: { ...this.inventory },
      parts: { ...this.parts },
      assembled: this.assembled,
      fueled: this.fueled,
      onboard: this.onboard,
      objective: this.objective(),
      location: this.sceneKind === "space" ? "Орбитальный полёт" : this.currentPlanet?.name || "Неизвестно",
      systemId: this.galaxy[this.currentSystem].id,
      systemName: this.galaxy[this.currentSystem].name,
      planetId: this.currentPlanet?.id || null,
      biome: this.sceneKind === "surface" ? this.currentPlanet?.biome || "space" : "space",
      danger: this.sceneKind === "surface" ? this.currentPlanet?.danger || 0 : Math.min(5, Math.ceil(this.currentSystem / 4)),
      level: this.level,
      xp: this.xp,
      xpNext: 100 + (this.level - 1) * 85,
      upgrades: { ...this.upgrades },
      visited: [...this.visited],
      network: { kind: this.networkKind, players: this.network ? this.network.peers.length + 1 : 1 },
      boss: activeBoss ? { name: "СТРАЖ ПУСТОТЫ", health: Math.max(0, activeBoss.hp), maxHealth: activeBoss.maxHp, stage: activeBoss.stage } : null,
      mining: this.mining ? { ...this.mining } : null,
      dead: this.dead,
      canCraft: this.canCraft(),
      scannerCooldown: this.scannerCooldown,
    };
  }

  private animate = (time: number) => {
    if (this.disposed) return;
    this.animationFrame = requestAnimationFrame(this.animate);
    const dt = Math.min(0.05, Math.max(0.001, (time - this.lastFrame) / 1000));
    this.lastFrame = time;
    this.elapsed += dt;
    this.fireCooldown = Math.max(0, this.fireCooldown - dt);
    this.scannerCooldown = Math.max(0, this.scannerCooldown - dt);
    if (this.enabled && !this.dead) {
      if (this.sceneKind === "surface") this.updateSurface(dt);
      else this.updateSpace(dt);
      this.updateEnemies(dt);
      this.updateProjectiles(dt);
      this.updatePrompt();
    }
    this.resources.forEach((resource) => {
      if (resource.type === "crystal" || resource.type === "crate") resource.group.rotation.y += dt * 0.1;
      const scanned = this.elapsed < this.scanUntil;
      const pulse = scanned ? 1 + Math.sin(this.elapsed * 7 + resource.group.position.x) * 0.07 : 1;
      resource.group.scale.setScalar(pulse);
    });
    this.updateRemotes(dt);
    if (time - this.lastSnapshot > 100) {
      this.lastSnapshot = time;
      this.hooks.onSnapshot(this.snapshot());
    }
    if (time - this.lastNetwork > 100) {
      this.lastNetwork = time;
      this.sendNetworkState();
    }
    this.renderer.render(this.scene, this.camera);
  };

  getGalaxy() {
    return this.galaxy;
  }

  getCurrentSystemId() {
    return this.galaxy[this.currentSystem].id;
  }

  getLandingTargetId() {
    return this.landingTarget?.id || null;
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.animationFrame);
    this.network?.close();
    this.audio.close();
    window.removeEventListener("resize", this.resize);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("mousemove", this.onMouseMove);
    window.removeEventListener("mousedown", this.onMouseDown);
    window.removeEventListener("mouseup", this.onMouseUp);
    document.removeEventListener("pointerlockchange", this.onPointerLock);
    this.renderer.domElement.removeEventListener("click", this.onCanvasClick);
    this.renderer.domElement.removeEventListener("contextmenu", this.preventContext);
    if (document.pointerLockElement === this.renderer.domElement) document.exitPointerLock();
    this.clearWorld();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}
