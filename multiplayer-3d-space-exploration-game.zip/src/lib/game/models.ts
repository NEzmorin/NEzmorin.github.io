import * as THREE from "three";

const material = (color: string | number, roughness = 0.8, metalness = 0.1) =>
  new THREE.MeshStandardMaterial({ color, roughness, metalness });

function mesh(geometry: THREE.BufferGeometry, mat: THREE.Material, position?: [number, number, number]) {
  const result = new THREE.Mesh(geometry, mat);
  if (position) result.position.set(...position);
  result.castShadow = true;
  result.receiveShadow = true;
  return result;
}

export function createShip(assembled = true) {
  const group = new THREE.Group();
  group.name = "old-ship";
  const rust = material(assembled ? "#716557" : "#594b40", 0.93, 0.5);
  const dark = material("#242a2a", 0.7, 0.75);
  const edge = material("#9a7655", 0.82, 0.65);
  const body = mesh(new THREE.CylinderGeometry(1.65, 2.05, 5.4, 12), rust, [0, 3.4, 0]);
  body.rotation.y = 0.15;
  group.add(body);
  group.add(mesh(new THREE.ConeGeometry(1.66, 2.3, 12), edge, [0, 7.25, 0]));
  group.add(mesh(new THREE.CylinderGeometry(1.72, 1.72, 0.25, 12), dark, [0, 5.6, 0]));
  const windowMat = new THREE.MeshStandardMaterial({ color: "#233d43", emissive: assembled ? "#5ca59c" : "#101819", emissiveIntensity: assembled ? 0.65 : 0.1, roughness: 0.22, metalness: 0.65 });
  const window = mesh(new THREE.SphereGeometry(0.72, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), windowMat, [0, 5.85, 1.25]);
  window.rotation.x = Math.PI / 2.8;
  group.add(window);
  for (let i = 0; i < 3; i += 1) {
    const angle = (i / 3) * Math.PI * 2;
    const leg = mesh(new THREE.CylinderGeometry(0.12, 0.16, 3.2, 6), dark);
    leg.position.set(Math.cos(angle) * 2.05, 1.25, Math.sin(angle) * 2.05);
    leg.rotation.z = Math.cos(angle) * 0.48;
    leg.rotation.x = Math.sin(angle) * 0.48;
    group.add(leg);
    const foot = mesh(new THREE.BoxGeometry(0.8, 0.15, 0.8), rust, [Math.cos(angle) * 2.65, 0.1, Math.sin(angle) * 2.65]);
    group.add(foot);
    if (assembled || i !== 1) {
      const nozzle = mesh(new THREE.CylinderGeometry(0.45, 0.7, 1.15, 10, 1, true), dark, [Math.cos(angle) * 0.95, 0.45, Math.sin(angle) * 0.95]);
      group.add(nozzle);
      if (assembled) {
        const glow = mesh(new THREE.CircleGeometry(0.43, 12), new THREE.MeshBasicMaterial({ color: "#df9258" }), [Math.cos(angle) * 0.95, -0.14, Math.sin(angle) * 0.95]);
        glow.rotation.x = Math.PI / 2;
        group.add(glow);
      }
    }
  }
  if (assembled) {
    const plate = mesh(new THREE.BoxGeometry(1.5, 1.9, 0.13), edge, [1.45, 3.3, 0]);
    plate.rotation.z = -0.12;
    group.add(plate);
    const antenna = mesh(new THREE.CylinderGeometry(0.035, 0.05, 1.8, 6), dark, [0.6, 8.1, 0]);
    antenna.rotation.z = -0.2;
    group.add(antenna);
  }
  return group;
}

export function createAstronaut(name: string) {
  const group = new THREE.Group();
  const suit = material("#c5bf9f", 0.8, 0.15);
  const dark = material("#282f31", 0.7, 0.5);
  group.add(mesh(new THREE.CapsuleGeometry(0.42, 0.8, 5, 10), suit, [0, 1.15, 0]));
  group.add(mesh(new THREE.SphereGeometry(0.42, 16, 12), dark, [0, 2.02, 0]));
  const visor = mesh(new THREE.SphereGeometry(0.35, 16, 10), new THREE.MeshStandardMaterial({ color: "#5d878b", emissive: "#27494c", emissiveIntensity: 0.5, metalness: 0.7, roughness: 0.2 }), [0, 2.02, -0.22]);
  visor.scale.set(0.9, 0.65, 0.45);
  group.add(visor);
  group.add(mesh(new THREE.BoxGeometry(0.65, 0.8, 0.3), dark, [0, 1.25, 0.4]));
  const label = createLabel(name);
  label.position.set(0, 2.85, 0);
  group.add(label);
  return group;
}

export function createRemoteShip() {
  const group = new THREE.Group();
  const ship = createShip(true);
  ship.scale.setScalar(0.6);
  ship.rotation.x = Math.PI / 2;
  ship.position.y = -1;
  group.add(ship);
  return group;
}

export function createLabel(text: string) {
  const canvas = document.createElement("canvas");
  canvas.width = 256;
  canvas.height = 48;
  const context = canvas.getContext("2d")!;
  context.fillStyle = "rgba(3,10,12,.75)";
  context.fillRect(0, 0, 256, 48);
  context.font = "22px monospace";
  context.textAlign = "center";
  context.fillStyle = "#d9e6d1";
  context.fillText(text.slice(0, 18), 128, 31);
  const texture = new THREE.CanvasTexture(canvas);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false }));
  sprite.scale.set(3.2, 0.6, 1);
  return sprite;
}

export function createResource(type: string, accent = "#9bb49a") {
  const group = new THREE.Group();
  if (type === "scrap" || type === "crate") {
    const mat = material(type === "crate" ? "#746d4c" : "#6d5d50", 0.8, 0.7);
    for (let i = 0; i < (type === "crate" ? 1 : 4); i += 1) {
      const piece = mesh(new THREE.BoxGeometry(0.8 + i * 0.12, 0.35 + i * 0.08, 0.65), mat, [(i - 1.5) * 0.22, 0.25 + i * 0.16, (i % 2) * 0.28]);
      piece.rotation.set(i * 0.17, i * 0.71, i * 0.11);
      group.add(piece);
    }
    if (type === "crate") {
      const stripe = mesh(new THREE.BoxGeometry(0.9, 0.12, 0.72), new THREE.MeshStandardMaterial({ color: accent, emissive: accent, emissiveIntensity: 0.35 }), [0, 0.48, 0]);
      group.add(stripe);
    }
  } else if (type === "crystal") {
    const mat = new THREE.MeshStandardMaterial({ color: accent, emissive: accent, emissiveIntensity: 0.55, roughness: 0.25, metalness: 0.15 });
    for (let i = 0; i < 4; i += 1) {
      const crystal = mesh(new THREE.ConeGeometry(0.25 + i * 0.05, 1.3 + i * 0.3, 5), mat, [(i - 1.5) * 0.3, 0.6 + i * 0.08, (i % 2) * 0.25]);
      crystal.rotation.z = (i - 1.5) * 0.18;
      group.add(crystal);
    }
  } else if (type === "fuelCell" || type === "medkit" || type === "part") {
    const color = type === "fuelCell" ? "#b78b45" : type === "medkit" ? "#a9b9aa" : "#7a6855";
    const item = mesh(new THREE.BoxGeometry(type === "part" ? 1.1 : 0.65, type === "part" ? 0.35 : 0.9, 0.65), material(color, 0.65, 0.6), [0, 0.45, 0]);
    group.add(item);
    const light = mesh(new THREE.BoxGeometry(0.25, 0.12, 0.68), new THREE.MeshBasicMaterial({ color: type === "medkit" ? "#b34f45" : "#d4bd66" }), [0, 0.65, 0]);
    group.add(light);
  } else {
    const color = type === "ore" ? "#736c61" : "#686c62";
    const rock = mesh(new THREE.DodecahedronGeometry(type === "ore" ? 1 : 0.9, 0), material(color, 0.98, type === "ore" ? 0.35 : 0.05), [0, 0.65, 0]);
    rock.scale.set(1.15, 0.85, 1);
    group.add(rock);
    if (type === "ore") {
      for (let i = 0; i < 3; i += 1) {
        group.add(mesh(new THREE.OctahedronGeometry(0.18, 0), new THREE.MeshStandardMaterial({ color: accent, emissive: accent, emissiveIntensity: 0.25, metalness: 0.8 }), [(i - 1) * 0.45, 0.85 + (i % 2) * 0.25, -0.55]));
      }
    }
  }
  return group;
}

export type EnemyModelType = "crawler" | "drone" | "turret" | "pirate" | "boss";

export function createEnemyModel(type: EnemyModelType) {
  const group = new THREE.Group();
  const dark = material("#292e30", 0.62, 0.75);
  const armor = material(type === "boss" ? "#655748" : "#535c57", 0.75, 0.65);
  const glowColor = type === "boss" ? "#e1784f" : "#d9a357";
  const glow = new THREE.MeshStandardMaterial({ color: glowColor, emissive: glowColor, emissiveIntensity: 1.4, roughness: 0.3 });
  if (type === "crawler") {
    const body = mesh(new THREE.DodecahedronGeometry(0.65, 0), armor, [0, 0.65, 0]);
    body.scale.z = 1.4;
    group.add(body);
    group.add(mesh(new THREE.SphereGeometry(0.18, 8, 6), glow, [0, 0.78, -0.75]));
    for (let i = 0; i < 6; i += 1) {
      const leg = mesh(new THREE.CylinderGeometry(0.045, 0.07, 1.15, 5), dark);
      leg.position.set(i < 3 ? -0.65 : 0.65, 0.35, ((i % 3) - 1) * 0.48);
      leg.rotation.z = i < 3 ? -0.95 : 0.95;
      group.add(leg);
    }
  } else if (type === "drone") {
    group.add(mesh(new THREE.SphereGeometry(0.62, 12, 8), armor));
    const ring = mesh(new THREE.TorusGeometry(0.9, 0.08, 6, 20), dark);
    ring.rotation.x = Math.PI / 2;
    group.add(ring);
    group.add(mesh(new THREE.SphereGeometry(0.2, 10, 8), glow, [0, 0, -0.55]));
  } else if (type === "turret") {
    group.add(mesh(new THREE.CylinderGeometry(0.75, 1, 0.65, 8), dark, [0, 0.32, 0]));
    const head = new THREE.Group();
    head.name = "head";
    head.position.y = 1.05;
    head.add(mesh(new THREE.BoxGeometry(1.1, 0.65, 1.25), armor));
    head.add(mesh(new THREE.CylinderGeometry(0.1, 0.13, 1.5, 8), dark, [0, 0, -1.1]));
    head.children[1].rotation.x = Math.PI / 2;
    head.add(mesh(new THREE.SphereGeometry(0.14, 8, 6), glow, [0, 0.12, -0.66]));
    group.add(head);
  } else if (type === "pirate") {
    const hull = mesh(new THREE.ConeGeometry(0.85, 3.2, 5), armor);
    hull.rotation.x = -Math.PI / 2;
    group.add(hull);
    const wings = mesh(new THREE.BoxGeometry(3.4, 0.12, 1.1), dark, [0, 0, 0.4]);
    group.add(wings);
    group.add(mesh(new THREE.SphereGeometry(0.2, 8, 6), glow, [0, 0, 1.55]));
  } else {
    const core = mesh(new THREE.IcosahedronGeometry(1.7, 1), armor, [0, 3.5, 0]);
    core.name = "boss-core";
    group.add(core);
    group.add(mesh(new THREE.IcosahedronGeometry(0.72, 2), glow, [0, 3.5, -1.35]));
    const halo = mesh(new THREE.TorusGeometry(2.5, 0.13, 8, 32), glow, [0, 3.5, 0]);
    halo.name = "boss-halo";
    halo.rotation.x = Math.PI / 2;
    group.add(halo);
    for (let i = 0; i < 6; i += 1) {
      const angle = (i / 6) * Math.PI * 2;
      const leg = mesh(new THREE.CylinderGeometry(0.13, 0.25, 4.8, 6), dark);
      leg.position.set(Math.cos(angle) * 2.2, 1.7, Math.sin(angle) * 2.2);
      leg.rotation.z = Math.cos(angle) * 0.65;
      leg.rotation.x = Math.sin(angle) * 0.65;
      group.add(leg);
    }
  }
  group.traverse((child) => {
    if (child instanceof THREE.Mesh && child.material === glow) child.name = "enemy-glow";
  });
  return group;
}
