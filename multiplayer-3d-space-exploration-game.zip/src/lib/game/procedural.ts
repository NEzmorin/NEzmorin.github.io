export type Biome = "home" | "verdant" | "desert" | "ice" | "ash" | "ruins" | "crystal";

export type PlanetDefinition = {
  id: string;
  name: string;
  seed: number;
  biome: Biome;
  radius: number;
  orbit: number;
  angle: number;
  color: string;
  accent: string;
  danger: number;
  richness: number;
  gravity: number;
  breathable: boolean;
  boss: boolean;
  description: string;
};

export type StarSystem = {
  id: string;
  name: string;
  seed: number;
  x: number;
  y: number;
  color: string;
  planets: PlanetDefinition[];
  home?: boolean;
};

const STAR_A = ["Астер", "Вейл", "Керн", "Лира", "Мирра", "Некс", "Орф", "Пylon", "Рея", "Сайн", "Тау", "Умбра", "Фар", "Хелио", "Цера", "Эон", "Юта", "Янтарь"];
const STAR_B = ["Прайм", "Минор", "Глубь", "Рубеж", "Тишина", "Исход", "Даль", "След", "Предел", "Отсвет"];
const PLANET_A = ["Ар", "Бел", "Вар", "Гео", "Дей", "Ерм", "Зен", "Ир", "Кал", "Лор", "Мек", "Нер", "Ост", "Пал", "Рун", "Сев", "Тал", "Урс", "Фен", "Хар", "Эр", "Юн"];
const PLANET_B = ["ион", "еда", "орс", "ания", "урн", "есс", "ера", "он", "арис", "илла", "ос", "ейт"];

export function hashString(value: string) {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

export function mulberry32(seed: number) {
  let value = seed >>> 0;
  return () => {
    value += 0x6d2b79f5;
    let result = value;
    result = Math.imul(result ^ (result >>> 15), result | 1);
    result ^= result + Math.imul(result ^ (result >>> 7), result | 61);
    return ((result ^ (result >>> 14)) >>> 0) / 4294967296;
  };
}

export function seeded(seed: number, salt: string) {
  return mulberry32((seed ^ hashString(salt)) >>> 0);
}

function pick<T>(random: () => number, values: readonly T[]) {
  return values[Math.floor(random() * values.length)] as T;
}

const BIOMES: Array<{ biome: Biome; color: string; accent: string; description: string }> = [
  { biome: "verdant", color: "#476d50", accent: "#a5c76c", description: "Спутые леса и следы старой терраформации." },
  { biome: "desert", color: "#9b6845", accent: "#e4b36d", description: "Пыльные дюны скрывают обломки экспедиций." },
  { biome: "ice", color: "#6f9da8", accent: "#c9f4ef", description: "Субнулевой мир с кристаллами под ледяной корой." },
  { biome: "ash", color: "#544e50", accent: "#d66e48", description: "Вулканический пепел, разломы и агрессивная фауна." },
  { biome: "ruins", color: "#626665", accent: "#d4b36b", description: "Мёртвый город. Металлолом ценнее местной руды." },
  { biome: "crystal", color: "#5b527d", accent: "#9be4db", description: "Резонирующие кристаллы питают сторожевые машины." },
];

export function generateGalaxy(worldSeed: number): StarSystem[] {
  const random = seeded(worldSeed, "galaxy");
  const systems: StarSystem[] = [];
  const homePlanet: PlanetDefinition = {
    id: "home-0",
    name: "Тихая",
    seed: seeded(worldSeed, "home-planet")() * 1e9,
    biome: "home",
    radius: 17,
    orbit: 130,
    angle: 0.5,
    color: "#657a58",
    accent: "#b7cc7a",
    danger: 0,
    richness: 1,
    gravity: 1,
    breathable: true,
    boss: false,
    description: "Единственная планета системы. Здесь остался ваш дом.",
  };
  systems.push({
    id: "home",
    name: "Астер",
    seed: worldSeed,
    x: 0,
    y: 0,
    color: "#f5cf83",
    home: true,
    planets: [homePlanet],
  });

  const usedNames = new Set<string>();
  for (let index = 1; index <= 18; index += 1) {
    const angle = index * 2.399 + random() * 0.45;
    const distance = 24 + index * 10 + random() * 22;
    const systemSeed = Math.floor(random() * 2_000_000_000);
    let name = `${pick(random, STAR_A)} ${pick(random, STAR_B)}`;
    while (usedNames.has(name)) name = `${pick(random, STAR_A)} ${pick(random, STAR_B)}`;
    usedNames.add(name);
    const planetCount = 2 + Math.floor(random() * 4);
    const planets: PlanetDefinition[] = [];
    for (let p = 0; p < planetCount; p += 1) {
      const info = pick(random, BIOMES);
      const danger = Math.min(5, Math.max(1, Math.floor(index / 4) + Math.floor(random() * 3)));
      const id = `${index}-${p}`;
      const boss = danger >= 3 && p === planetCount - 1 && index % 4 === 0;
      planets.push({
        id,
        name: `${pick(random, PLANET_A)}${pick(random, PLANET_B)} ${p + 1}`,
        seed: Math.floor(random() * 2_000_000_000),
        biome: info.biome,
        radius: 11 + random() * 14,
        orbit: 90 + p * 72 + random() * 25,
        angle: random() * Math.PI * 2,
        color: info.color,
        accent: info.accent,
        danger,
        richness: 1 + Math.floor(random() * 3),
        gravity: 0.75 + random() * 0.65,
        breathable: info.biome === "verdant" && random() > 0.45,
        boss,
        description: boss ? `${info.description} Зафиксирован сигнал древнего Стража.` : info.description,
      });
    }
    systems.push({
      id: String(index),
      name,
      seed: systemSeed,
      x: Math.cos(angle) * distance,
      y: Math.sin(angle) * distance,
      color: pick(random, ["#f6d493", "#f49a74", "#b6d8ee", "#ddd7ff"]),
      planets,
    });
  }
  return systems;
}

export function systemDistance(a: StarSystem, b: StarSystem) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

export function formatNumber(value: number) {
  return Math.max(0, Math.floor(value)).toLocaleString("ru-RU");
}
