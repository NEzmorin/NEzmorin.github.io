import type { NetworkKind } from "./network";

export type GameMode = "standard" | "sandbox";
export type SceneKind = "surface" | "space";
export type OverlayKind = "inventory" | "map" | "sandbox" | "pause" | "death" | null;
export type ItemId = "ore" | "stone" | "scrap" | "crystal" | "cannedFood" | "fuelCell" | "medkit";
export type UpgradeId = "engine" | "tank" | "laser" | "shield";
export type SpawnId = "ore" | "stone" | "scrap" | "crystal" | "crate" | "fuelCell" | "medkit" | "part" | "crawler" | "drone" | "turret" | "pirate" | "boss";

export type GameOptions = {
  seed: number;
  mode: GameMode;
  playerId: string;
  playerName: string;
  roomCode?: string;
};

export type Inventory = Record<ItemId, number>;

export type GameSnapshot = {
  scene: SceneKind;
  health: number;
  maxHealth: number;
  oxygen: number;
  fuel: number;
  maxFuel: number;
  speed: number;
  inventory: Inventory;
  parts: { engine: boolean; hull: boolean; nav: boolean };
  assembled: boolean;
  fueled: boolean;
  onboard: boolean;
  objective: string;
  location: string;
  systemId: string;
  systemName: string;
  planetId: string | null;
  biome: string;
  danger: number;
  level: number;
  xp: number;
  xpNext: number;
  upgrades: Record<UpgradeId, number>;
  visited: string[];
  network: { kind: NetworkKind | "offline" | "connecting"; players: number };
  boss: { name: string; health: number; maxHealth: number; stage: number } | null;
  mining: { label: string; progress: number } | null;
  dead: boolean;
  canCraft: boolean;
  scannerCooldown: number;
};

export type PromptState = {
  key: string;
  title: string;
  detail?: string;
} | null;

export type EngineHooks = {
  onSnapshot: (snapshot: GameSnapshot) => void;
  onPrompt: (prompt: PromptState) => void;
  onOverlay: (overlay: OverlayKind) => void;
  onToast: (message: string, tone?: "info" | "good" | "danger") => void;
  onDiscovery: (planet: { key: string; name: string; systemName: string; biome: string }) => void;
};

export const EMPTY_INVENTORY: Inventory = {
  ore: 0,
  stone: 0,
  scrap: 0,
  crystal: 0,
  cannedFood: 0,
  fuelCell: 0,
  medkit: 0,
};

export const ITEM_NAMES: Record<ItemId, string> = {
  ore: "Железная руда",
  stone: "Камень",
  scrap: "Металлолом",
  crystal: "Резонансный кристалл",
  cannedFood: "Старая консерва",
  fuelCell: "Топливный элемент",
  medkit: "Аптечка",
};

export const UPGRADE_NAMES: Record<UpgradeId, string> = {
  engine: "Форсированный двигатель",
  tank: "Дополнительный бак",
  laser: "Фокусировка лазера",
  shield: "Аварийный экран",
};
