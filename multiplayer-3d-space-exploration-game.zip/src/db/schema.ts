import { sql } from "drizzle-orm";
import {
  index,
  integer,
  pgTable,
  serial,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

export const presence = pgTable(
  "presence",
  {
    playerId: varchar("player_id", { length: 80 }).primaryKey(),
    name: varchar("name", { length: 32 }).notNull(),
    status: varchar("status", { length: 16 }).notNull().default("online"),
    lastSeen: timestamp("last_seen", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("presence_last_seen_idx").on(table.lastSeen)],
);

export const lobbies = pgTable("lobbies", {
  code: varchar("code", { length: 12 }).primaryKey(),
  hostId: varchar("host_id", { length: 80 }).notNull(),
  hostName: varchar("host_name", { length: 32 }).notNull(),
  title: varchar("title", { length: 48 }).notNull(),
  mode: varchar("mode", { length: 16 }).notNull().default("standard"),
  maxPlayers: integer("max_players").notNull().default(4),
  worldSeed: integer("world_seed").notNull(),
  status: varchar("status", { length: 16 }).notNull().default("waiting"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const lobbyMembers = pgTable(
  "lobby_members",
  {
    id: serial("id").primaryKey(),
    lobbyCode: varchar("lobby_code", { length: 12 })
      .notNull()
      .references(() => lobbies.code, { onDelete: "cascade" }),
    playerId: varchar("player_id", { length: 80 }).notNull(),
    name: varchar("name", { length: 32 }).notNull(),
    joinedAt: timestamp("joined_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("lobby_member_unique").on(table.lobbyCode, table.playerId)],
);

export const discoveries = pgTable(
  "discoveries",
  {
    id: serial("id").primaryKey(),
    playerId: varchar("player_id", { length: 80 }).notNull(),
    playerName: varchar("player_name", { length: 32 }).notNull(),
    planetKey: varchar("planet_key", { length: 100 }).notNull(),
    planetName: varchar("planet_name", { length: 48 }).notNull(),
    systemName: varchar("system_name", { length: 48 }).notNull(),
    biome: varchar("biome", { length: 32 }).notNull(),
    discoveredAt: timestamp("discovered_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("discovery_player_planet_unique").on(table.playerId, table.planetKey)],
);

export const activePresenceFilter = sql`${presence.lastSeen} > now() - interval '45 seconds'`;
