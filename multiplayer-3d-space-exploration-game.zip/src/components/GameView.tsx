"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { GameEngine } from "@/lib/game/GameEngine";
import { generateGalaxy, systemDistance } from "@/lib/game/procedural";
import { ITEM_NAMES, UPGRADE_NAMES, type GameOptions, type GameSnapshot, type OverlayKind, type PromptState, type SpawnId, type UpgradeId } from "@/lib/game/engine-types";

type Toast = { id: number; message: string; tone: "info" | "good" | "danger" };

const BIOME_NAMES: Record<string, string> = { home: "Родной мир", verdant: "Зелёный", desert: "Пустынный", ice: "Ледяной", ash: "Пепельный", ruins: "Мёртвый город", crystal: "Кристаллический", space: "Открытый космос" };
const SANDBOX_ITEMS: Array<{ id: SpawnId; name: string; detail: string; group: string }> = [
  { id: "part", name: "Комплект деталей", detail: "Недостающая деталь корабля", group: "Предметы" },
  { id: "fuelCell", name: "Топливный элемент", detail: "+45 единиц в кабине", group: "Предметы" },
  { id: "medkit", name: "Аптечка", detail: "Восстанавливает 60 здоровья", group: "Предметы" },
  { id: "crate", name: "Контейнер", detail: "Случайные припасы внутри", group: "Предметы" },
  { id: "ore", name: "Железная жила", detail: "Разрушается мультитулом", group: "Ресурсы" },
  { id: "stone", name: "Каменная жила", detail: "Строительный ресурс", group: "Ресурсы" },
  { id: "scrap", name: "Металлолом", detail: "Детали для модулей", group: "Ресурсы" },
  { id: "crystal", name: "Кристалл", detail: "Редкий энергетический ресурс", group: "Ресурсы" },
  { id: "crawler", name: "Пепельный ползун", detail: "Быстрая атака вблизи", group: "Угрозы" },
  { id: "drone", name: "Дрон-следопыт", detail: "Стрейф и заряжаемый выстрел", group: "Угрозы" },
  { id: "turret", name: "Турель руин", detail: "Дальняя тяжёлая атака", group: "Угрозы" },
  { id: "pirate", name: "Космический пират", detail: "Только открытый космос", group: "Угрозы" },
  { id: "boss", name: "Страж Пустоты", detail: "Три боевые фазы", group: "Угрозы" },
];

function Bar({ value, max, kind, label }: { value: number; max: number; kind: string; label: string }) {
  const percent = Math.max(0, Math.min(100, (value / Math.max(1, max)) * 100));
  return <div className={`hud-bar ${kind}`}><div><span>{label}</span><b>{Math.ceil(value)}<small> / {max}</small></b></div><i><em style={{ width: `${percent}%` }} /></i></div>;
}

export default function GameView({ options, onExit }: { options: GameOptions; onExit: () => void }) {
  const mount = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [snapshot, setSnapshot] = useState<GameSnapshot | null>(null);
  const [prompt, setPrompt] = useState<PromptState>(null);
  const [overlay, setOverlay] = useState<OverlayKind>(null);
  const [started, setStarted] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [selectedSystem, setSelectedSystem] = useState("home");
  const [chat, setChat] = useState("");
  const [engineError, setEngineError] = useState("");
  const galaxy = useMemo(() => generateGalaxy(options.seed), [options.seed]);
  const toastId = useRef(0);

  useEffect(() => {
    if (!mount.current) return;
    const addToast = (message: string, tone: Toast["tone"] = "info") => {
      const id = ++toastId.current;
      setToasts((items) => [...items.slice(-4), { id, message, tone }]);
      window.setTimeout(() => setToasts((items) => items.filter((item) => item.id !== id)), 4_200);
    };
    try {
      const engine = new GameEngine(mount.current, options, {
        onSnapshot: setSnapshot,
        onPrompt: setPrompt,
        onOverlay: (next) => {
          setOverlay(next);
          if (next === "map") setSelectedSystem(engineRef.current?.getCurrentSystemId() || "home");
        },
        onToast: addToast,
        onDiscovery: (planet) => {
          void fetch("/api/discoveries", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ playerId: options.playerId, playerName: options.playerName, ...planet }) });
        },
      });
      engineRef.current = engine;
    } catch (error) {
      console.error(error);
      setEngineError("Не удалось запустить WebGL. Проверьте аппаратное ускорение браузера.");
    }
    return () => {
      engineRef.current?.dispose();
      engineRef.current = null;
    };
  }, [options]);

  const closeOverlay = () => {
    setOverlay(null);
    engineRef.current?.resume();
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (!started || !overlay || overlay === "death") return;
      if (event.code === "Escape" || (event.code === "Tab" && overlay === "inventory") || (event.code === "KeyM" && overlay === "map") || (event.code === "KeyB" && overlay === "sandbox")) {
        event.preventDefault();
        closeOverlay();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [overlay, started]);

  const currentSystem = galaxy.find((system) => system.id === snapshot?.systemId) || galaxy[0];
  const selected = galaxy.find((system) => system.id === selectedSystem) || currentSystem;
  const jumpCost = Math.max(2, Math.ceil(systemDistance(currentSystem, selected) / 11));
  const nearest = useMemo(() => galaxy.filter((system) => system.id !== currentSystem.id).sort((a, b) => systemDistance(currentSystem, a) - systemDistance(currentSystem, b)).slice(0, 4), [galaxy, currentSystem]);

  const craft = (id: UpgradeId) => {
    engineRef.current?.craft(id);
  };

  const jump = () => {
    if (engineRef.current?.jumpToSystem(selected.id)) closeOverlay();
  };

  const spawn = (id: SpawnId) => {
    engineRef.current?.spawnSandbox(id);
    closeOverlay();
  };

  const sendChat = () => {
    if (!chat.trim()) return;
    engineRef.current?.sendChat(chat);
    setChat("");
  };

  return (
    <main className={`game-shell ${snapshot?.scene === "space" ? "in-space" : "on-surface"}`}>
      <div ref={mount} className="game-mount" />
      {engineError && <div className="engine-error"><h2>СБОЙ ВИЗУАЛИЗАЦИИ</h2><p>{engineError}</p><button onClick={onExit}>ВЕРНУТЬСЯ В МЕНЮ</button></div>}
      {snapshot && started && !overlay && (
        <div className="hud-layer">
          <div className="hud-top-left">
            <div className="objective-label"><span>ТЕКУЩАЯ ЗАДАЧА</span><i /></div>
            <p>{snapshot.objective}</p>
            <div className="location-line"><b>{snapshot.location}</b><span>{snapshot.systemName} / {BIOME_NAMES[snapshot.biome] || snapshot.biome}</span></div>
          </div>
          <div className="hud-top-right">
            <div className="network-chip"><span className={`status-dot ${snapshot.network.kind === "offline" ? "muted" : ""}`} /><b>{snapshot.network.kind === "staralgo" ? "STARALGO" : snapshot.network.kind === "broadcast" ? "ЛОКАЛЬНЫЙ КАНАЛ" : snapshot.network.kind === "connecting" ? "ПОДКЛЮЧЕНИЕ" : "ОДИНОЧНАЯ ИГРА"}</b><small>{snapshot.network.players} В ЭКСПЕДИЦИИ</small></div>
            {options.mode === "sandbox" && <div className="sandbox-chip">ПЕСОЧНИЦА <kbd>B</kbd></div>}
            <div className="level-chip"><span>РАНГ {String(snapshot.level).padStart(2, "0")}</span><i><em style={{ width: `${(snapshot.xp / snapshot.xpNext) * 100}%` }} /></i></div>
          </div>
          <div className="crosshair"><i /><i /><span /></div>
          {snapshot.mining && <div className="mine-readout"><span>{snapshot.mining.label}</span><i><em style={{ width: `${snapshot.mining.progress * 100}%` }} /></i></div>}
          {prompt && <div className="interact-prompt"><kbd>{prompt.key}</kbd><div><b>{prompt.title}</b>{prompt.detail && <span>{prompt.detail}</span>}</div></div>}
          {snapshot.boss && <div className="boss-hud"><div><span>{snapshot.boss.name}</span><b>ФАЗА {["I", "II", "III"][snapshot.boss.stage - 1]}</b></div><i><em style={{ width: `${(snapshot.boss.health / snapshot.boss.maxHealth) * 100}%` }} /></i><small>{snapshot.boss.stage === 1 ? "УДАРНАЯ ВОЛНА · НЕ СТОЙТЕ РЯДОМ" : snapshot.boss.stage === 2 ? "РАКЕТНЫЙ РОЙ · ДЕРЖИТЕ ДИСТАНЦИЮ" : "ЯДРО РАСКРЫТО · УРОН УВЕЛИЧЕН"}</small></div>}
          <div className="hud-bottom-left">
            <Bar value={snapshot.health} max={snapshot.maxHealth} kind="health" label="СКАФАНДР" />
            {snapshot.scene === "surface" && <Bar value={snapshot.oxygen} max={100} kind="oxygen" label="КИСЛОРОД" />}
            <Bar value={snapshot.fuel} max={snapshot.maxFuel} kind="fuel" label="ТОПЛИВО" />
            <div className="quick-items"><button onClick={() => engineRef.current?.useItem("cannedFood")}><kbd>1</kbd><span>КОНСЕРВА</span><b>{snapshot.inventory.cannedFood}</b></button><button onClick={() => engineRef.current?.useItem("medkit")}><kbd>2</kbd><span>АПТЕЧКА</span><b>{snapshot.inventory.medkit}</b></button><button onClick={() => engineRef.current?.useItem("fuelCell")}><kbd>↯</kbd><span>ЭЛЕМЕНТ</span><b>{snapshot.inventory.fuelCell}</b></button></div>
          </div>
          <div className="hud-bottom-right">
            {snapshot.scene === "space" ? <div className="velocity"><span>СКОРОСТЬ</span><b>{Math.round(snapshot.speed * 12).toLocaleString("ru-RU")}</b><small>М/С</small><div className="thrust-lines"><i /><i /><i /><i /></div></div> : <div className="tool-readout"><span>МУЛЬТИТУЛ / MK.{snapshot.upgrades.laser + 1}</span><b>{25 + snapshot.upgrades.laser * 12 + (snapshot.level - 1) * 2} <small>УРОН/С</small></b></div>}
            <div className="resource-strip"><span>FE <b>{snapshot.inventory.ore}</b></span><span>STONE <b>{snapshot.inventory.stone}</b></span><span>SCRAP <b>{snapshot.inventory.scrap}</b></span><span>CR <b>{snapshot.inventory.crystal}</b></span></div>
            <div className="hud-hints"><span><kbd>TAB</kbd> СНАРЯЖЕНИЕ</span><span><kbd>M</kbd> КАРТА</span><span><kbd>R</kbd> СКАНЕР {snapshot.scannerCooldown > 0 ? `${Math.ceil(snapshot.scannerCooldown)}S` : "ГОТОВ"}</span></div>
          </div>
          {snapshot.scene === "space" && <div className="cockpit-frame"><i className="cockpit-left" /><i className="cockpit-right" /><span>FH—07 / FLIGHT CONTROL</span></div>}
        </div>
      )}

      <div className="toast-stack">{toasts.map((toast) => <div key={toast.id} className={`game-toast ${toast.tone}`}><i />{toast.message}</div>)}</div>

      {!started && !engineError && (
        <div className="wake-screen">
          <div className="wake-card"><p className="panel-eyebrow">СИСТЕМА АСТЕР / ПЛАНЕТА ТИХАЯ</p><h2>Сигнал будильника<br />пробился сквозь статику.</h2><p>Дом цел. Космогараж всё ещё стоит. За стеной вас ждёт ржавый корабль — если получится собрать его заново.</p><div className="wake-controls"><span><kbd>WASD</kbd> ИДТИ</span><span><kbd>МЫШЬ</kbd> ОСМОТР</span><span><kbd>E</kbd> ДЕЙСТВИЕ</span></div><button onClick={() => { setStarted(true); engineRef.current?.resume(); }}>ПРОСНУТЬСЯ <span>→</span></button><small>Нажатие захватит курсор. ESC — пауза.</small></div>
        </div>
      )}

      {overlay === "inventory" && snapshot && (
        <div className="game-modal-backdrop"><section className="game-modal inventory-modal"><header><div><p className="panel-eyebrow">СНАРЯЖЕНИЕ / РАНГ {snapshot.level}</p><h2>Полевой инвентарь</h2></div><button className="modal-close" onClick={closeOverlay}>TAB · ЗАКРЫТЬ</button></header><div className="inventory-layout"><div><h3>РЕСУРСЫ И ПРИПАСЫ</h3><div className="inventory-grid">{(Object.keys(snapshot.inventory) as Array<keyof typeof snapshot.inventory>).map((item) => <div key={item} className={snapshot.inventory[item] === 0 ? "empty" : ""}><span>{ITEM_NAMES[item]}</span><b>{snapshot.inventory[item]}</b>{["cannedFood", "medkit", "fuelCell"].includes(item) && <button onClick={() => engineRef.current?.useItem(item)}>ИСПОЛЬЗОВАТЬ</button>}</div>)}</div><div className="parts-status"><h3>РЕМОНТНЫЙ КОМПЛЕКТ</h3><span className={snapshot.parts.engine ? "done" : ""}>Плазменная катушка <b>{snapshot.parts.engine ? "НАЙДЕНА" : "—"}</b></span><span className={snapshot.parts.hull ? "done" : ""}>Лист обшивки <b>{snapshot.parts.hull ? "НАЙДЕН" : "—"}</b></span><span className={snapshot.parts.nav ? "done" : ""}>Навигационный блок <b>{snapshot.parts.nav ? "НАЙДЕН" : "—"}</b></span></div></div><div><h3>МОДУЛИ КОРАБЛЯ <small>{snapshot.canCraft ? "ВЕРФЬ ДОСТУПНА" : "ПОДОЙДИТЕ К КОРАБЛЮ"}</small></h3><div className="upgrade-list">{(Object.keys(snapshot.upgrades) as UpgradeId[]).map((id) => { const recipe = engineRef.current?.getRecipe(id) || { ore: 0, stone: 0, scrap: 0, crystal: 0 }; const max = id === "laser" ? 3 : 2; return <div key={id}><div><b>{UPGRADE_NAMES[id]}</b><span>УРОВЕНЬ {snapshot.upgrades[id]} / {max}</span></div><p>{id === "engine" ? "+18 к предельной скорости" : id === "tank" ? "+55 к ёмкости бака" : id === "laser" ? "+13 к урону и скорострельности" : "+25 к прочности, −9% входящего урона"}</p><div className="recipe">{(Object.entries(recipe) as Array<[keyof typeof snapshot.inventory, number]>).filter(([, amount]) => amount > 0).map(([item, amount]) => <span key={item} className={snapshot.inventory[item] < amount ? "missing" : ""}>{ITEM_NAMES[item]} <b>{amount}</b></span>)}</div><button onClick={() => craft(id)} disabled={!snapshot.canCraft || snapshot.upgrades[id] >= max}>{snapshot.upgrades[id] >= max ? "МАКСИМУМ" : "УСТАНОВИТЬ МОДУЛЬ"}</button></div>; })}</div></div></div></section></div>
      )}

      {overlay === "map" && snapshot && (
        <div className="game-modal-backdrop"><section className="game-modal map-modal"><header><div><p className="panel-eyebrow">НАВИГАЦИОННЫЙ АРХИВ / SEED {options.seed}</p><h2>Карта ближайших звёзд</h2></div><button className="modal-close" onClick={closeOverlay}>M · ЗАКРЫТЬ</button></header><div className="map-layout"><div className="star-map"><svg viewBox="-300 -300 600 600" role="img" aria-label="Процедурная карта звёздных систем"><defs><radialGradient id="mapGlow"><stop offset="0" stopColor="#e4d19a" stopOpacity=".8" /><stop offset="1" stopColor="#e4d19a" stopOpacity="0" /></radialGradient></defs><circle cx="0" cy="0" r="260" className="map-orbit" /><circle cx="0" cy="0" r="170" className="map-orbit" /><circle cx="0" cy="0" r="85" className="map-orbit" /><line x1={currentSystem.x} y1={currentSystem.y} x2={selected.x} y2={selected.y} className="route-line" />{galaxy.map((system) => <g key={system.id} transform={`translate(${system.x} ${system.y})`} className={`map-star ${system.id === currentSystem.id ? "current" : ""} ${system.id === selected.id ? "selected" : ""}`} onClick={() => setSelectedSystem(system.id)}><circle r="18" fill="url(#mapGlow)" /><circle r={system.id === currentSystem.id ? 5 : 3.5} style={{ fill: system.color }} /><text x="9" y="-8">{system.name}</text><text x="9" y="5" className="map-system-meta">{system.planets.length} ПЛАН.</text></g>)}</svg><div className="map-legend"><span><i className="current-dot" /> ТЕКУЩАЯ СИСТЕМА</span><span><i className="selected-dot" /> ВЫБРАННЫЙ КУРС</span></div></div><aside className="system-details"><p className="panel-eyebrow">СИСТЕМА / {selected.id.toUpperCase()}</p><h3>{selected.name}</h3><div className="system-stats"><span>РАССТОЯНИЕ <b>{systemDistance(currentSystem, selected).toFixed(1)} св. ед.</b></span><span>ПЛАНЕТ <b>{selected.planets.length}</b></span><span>ЦЕНА ПРЫЖКА <b>{selected.id === currentSystem.id ? "—" : `${jumpCost} топлива`}</b></span></div><div className="planet-list">{selected.planets.map((planet) => <div key={planet.id}><i style={{ background: planet.color, borderColor: planet.accent }} /><div><b>{planet.name}</b><span>{BIOME_NAMES[planet.biome]} · угроза {planet.danger}/5</span><small>{planet.description}</small></div>{planet.boss && <em>СИГНАЛ СТРАЖА</em>}</div>)}</div>{selected.id !== currentSystem.id ? <button className="jump-button" onClick={jump} disabled={snapshot.scene !== "space" || snapshot.fuel < jumpCost}>{snapshot.scene !== "space" ? "НУЖНО НАХОДИТЬСЯ В КОСМОСЕ" : snapshot.fuel < jumpCost ? "НЕДОСТАТОЧНО ТОПЛИВА" : `СОВЕРШИТЬ ПРЫЖОК · −${jumpCost}`}</button> : <div className="current-system-note">ВЫ НАХОДИТЕСЬ ЗДЕСЬ. Для посадки подлетите к планете в открытом космосе и нажмите E.</div>}<div className="nearest-list"><b>БЛИЖАЙШИЕ СИГНАЛЫ</b>{nearest.map((system) => <button key={system.id} onClick={() => setSelectedSystem(system.id)}><span>{system.name}</span><small>{systemDistance(currentSystem, system).toFixed(0)} ед. →</small></button>)}</div></aside></div></section></div>
      )}

      {overlay === "sandbox" && snapshot && (
        <div className="game-modal-backdrop"><section className="game-modal sandbox-modal"><header><div><p className="panel-eyebrow">РЕЖИМ ПЕСОЧНИЦЫ / СОЗДАНИЕ ОБЪЕКТОВ</p><h2>Генератор материи</h2></div><button className="modal-close" onClick={closeOverlay}>B · ЗАКРЫТЬ</button></header><p className="sandbox-note">Объект появится перед вами. В сетевой игре команда спавна передаётся остальным участникам той же планеты.</p><div className="spawn-groups">{["Предметы", "Ресурсы", "Угрозы"].map((group) => <div key={group}><h3>{group}</h3><div>{SANDBOX_ITEMS.filter((item) => item.group === group).map((item) => <button key={item.id} onClick={() => spawn(item.id)}><span className={`spawn-icon ${item.group === "Угрозы" ? "hostile" : ""}`}>{item.id.slice(0, 2).toUpperCase()}</span><b>{item.name}</b><small>{item.detail}</small><i>+</i></button>)}</div></div>)}</div></section></div>
      )}

      {overlay === "pause" && snapshot && (
        <div className="game-modal-backdrop pause-backdrop"><section className="pause-menu"><p className="panel-eyebrow">ЭКСПЕДИЦИЯ ПРИОСТАНОВЛЕНА</p><h2>{snapshot.location}</h2><p>{snapshot.systemName} · {snapshot.network.players} участник(а) · {options.mode === "sandbox" ? "песочница" : "стандарт"}</p><button className="form-submit" onClick={closeOverlay}>ВЕРНУТЬСЯ В ЭКСПЕДИЦИЮ →</button><div className="pause-controls"><span><kbd>WASD</kbd> движение / тяга</span><span><kbd>SHIFT</kbd> бег / форсаж</span><span><kbd>ЛКМ</kbd> мультитул / лазер</span><span><kbd>E</kbd> действие / посадка</span><span><kbd>R</kbd> импульс сканера</span><span><kbd>F</kbd> фонарь</span></div>{options.roomCode && <div className="ship-chat"><b>КАНАЛ ЭКСПЕДИЦИИ</b><div><input value={chat} onChange={(event) => setChat(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") sendChat(); }} placeholder="Сообщение экипажу…" maxLength={160} /><button onClick={sendChat}>ОТПРАВИТЬ</button></div><small>{snapshot.network.kind === "broadcast" ? "BroadcastChannel: сообщения только между вкладками этого браузера" : snapshot.network.kind === "staralgo" ? "StarAlgo relay · комната " + options.roomCode : "Канал ещё подключается"}</small></div>}<button className="leave-game" onClick={onExit}>ПОКИНУТЬ ЭКСПЕДИЦИЮ</button></section></div>
      )}

      {overlay === "death" && (
        <div className="death-screen"><div><p className="panel-eyebrow">АВАРИЙНЫЙ КОНТУР / СИГНАЛ ПОТЕРЯН</p><h2>Скафандр<br />молчит.</h2><p>Автоматика успела зафиксировать резервный отпечаток. Возрождение сохранит модули, но унесёт 20% сыпучих ресурсов.</p><button onClick={() => { engineRef.current?.respawn(); setOverlay(null); engineRef.current?.resume(); }}>ВОССТАНОВИТЬ ОТПЕЧАТОК →</button><button className="leave-game" onClick={onExit}>ВЕРНУТЬСЯ В ГЛАВНОЕ МЕНЮ</button></div></div>
      )}
    </main>
  );
}
