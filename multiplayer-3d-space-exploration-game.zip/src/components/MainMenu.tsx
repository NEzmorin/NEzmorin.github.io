"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import MenuPlanet from "./MenuPlanet";
import GameView from "./GameView";
import type { GameMode, GameOptions } from "@/lib/game/engine-types";

type Presence = { playing: number; online: number; total: number };
type Lobby = {
  code: string;
  hostId: string;
  hostName: string;
  title: string;
  mode: GameMode;
  maxPlayers: number;
  worldSeed: number;
  status: "waiting" | "playing";
  players: number;
};
type Member = { playerId: string; name: string };
type Discovery = { id: number; planetName: string; playerName: string; systemName: string; biome: string; discoveredAt: string };
type View = "menu" | "create" | "join" | "lobby" | "manual";

const BIOME_NAMES: Record<string, string> = { home: "Дом", verdant: "Лес", desert: "Пустыня", ice: "Лёд", ash: "Пепел", ruins: "Руины", crystal: "Кристаллы" };

export default function MainMenu() {
  const [playerId, setPlayerId] = useState("");
  const [playerName, setPlayerName] = useState("Странник");
  const [presence, setPresence] = useState<Presence>({ playing: 0, online: 0, total: 0 });
  const [view, setView] = useState<View>("menu");
  const [planetSeed, setPlanetSeed] = useState(741903);
  const [session, setSession] = useState<GameOptions | null>(null);
  const [lobbies, setLobbies] = useState<Lobby[]>([]);
  const [activeLobby, setActiveLobby] = useState<Lobby | null>(null);
  const [members, setMembers] = useState<Member[]>([]);
  const [joinCode, setJoinCode] = useState("");
  const [title, setTitle] = useState("Экспедиция в неизвестность");
  const [maxPlayers, setMaxPlayers] = useState(4);
  const [mode, setMode] = useState<GameMode>("standard");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [discoveries, setDiscoveries] = useState<Discovery[]>([]);

  useEffect(() => {
    setPlanetSeed(Math.floor(Math.random() * 2_000_000_000));
    let id = localStorage.getItem("farhome-player-id");
    if (!id) {
      id = `traveler-${crypto.randomUUID()}`;
      localStorage.setItem("farhome-player-id", id);
    }
    const savedName = localStorage.getItem("farhome-player-name");
    if (savedName) setPlayerName(savedName);
    setPlayerId(id);
  }, []);

  const refreshPresence = useCallback(async (status: "online" | "playing" = session ? "playing" : "online") => {
    if (!playerId) return;
    try {
      const response = await fetch("/api/presence", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ playerId, name: playerName, status }) });
      if (response.ok) setPresence(await response.json() as Presence);
    } catch {
      // The menu remains playable without the presence service.
    }
  }, [playerId, playerName, session]);

  useEffect(() => {
    void refreshPresence();
    const heartbeat = setInterval(() => void refreshPresence(), 15_000);
    return () => clearInterval(heartbeat);
  }, [refreshPresence]);

  const refreshLobbies = useCallback(async () => {
    try {
      const response = await fetch("/api/lobbies", { cache: "no-store" });
      const data = await response.json() as { lobbies?: Lobby[] };
      setLobbies(data.lobbies || []);
    } catch {
      setLobbies([]);
    }
  }, []);

  useEffect(() => {
    void refreshLobbies();
    void fetch("/api/discoveries").then((response) => response.json()).then((data: { discoveries?: Discovery[] }) => setDiscoveries(data.discoveries || [])).catch(() => undefined);
    const interval = setInterval(() => void refreshLobbies(), 5_000);
    return () => clearInterval(interval);
  }, [refreshLobbies]);

  const launchLobby = useCallback((lobby: Lobby) => {
    setSession({ seed: lobby.worldSeed, mode: lobby.mode, playerId, playerName, roomCode: lobby.code });
  }, [playerId, playerName]);

  useEffect(() => {
    if (!activeLobby || session) return;
    const poll = async () => {
      try {
        const response = await fetch(`/api/lobbies?code=${activeLobby.code}`, { cache: "no-store" });
        const data = await response.json() as { lobby: Lobby | null; members: Member[] };
        if (!data.lobby) {
          setActiveLobby(null);
          setView("menu");
          setError("Хост закрыл лобби");
          return;
        }
        setActiveLobby(data.lobby);
        setMembers(data.members);
        if (data.lobby.status === "playing") launchLobby(data.lobby);
      } catch {
        // Keep the last good lobby state during a transient network failure.
      }
    };
    void poll();
    const interval = setInterval(() => void poll(), 2_000);
    return () => clearInterval(interval);
  }, [activeLobby?.code, session, launchLobby]);

  const quickPlay = () => {
    if (!playerId) return;
    setSession({ seed: Math.floor(Math.random() * 2_000_000_000), mode: "sandbox", playerId, playerName });
  };

  const createLobby = async () => {
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/lobbies", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "create", playerId, name: playerName, title, maxPlayers, mode }) });
      const data = await response.json() as { code?: string; error?: string };
      if (!response.ok || !data.code) throw new Error(data.error || "Не удалось создать лобби");
      await refreshLobbies();
      const detail = await fetch(`/api/lobbies?code=${data.code}`).then((result) => result.json()) as { lobby: Lobby; members: Member[] };
      setActiveLobby(detail.lobby);
      setMembers(detail.members);
      setView("lobby");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Ошибка соединения");
    } finally {
      setBusy(false);
    }
  };

  const joinLobby = async (code: string) => {
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/lobbies", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "join", code, playerId, name: playerName }) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Не удалось войти");
      const detail = await fetch(`/api/lobbies?code=${code}`).then((result) => result.json()) as { lobby: Lobby; members: Member[] };
      setActiveLobby(detail.lobby);
      setMembers(detail.members);
      setView("lobby");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Ошибка соединения");
    } finally {
      setBusy(false);
    }
  };

  const leaveLobby = async () => {
    if (activeLobby) await fetch("/api/lobbies", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "leave", code: activeLobby.code, playerId }) }).catch(() => undefined);
    setActiveLobby(null);
    setMembers([]);
    setView("menu");
    void refreshLobbies();
  };

  const hostLaunch = async () => {
    if (!activeLobby) return;
    setBusy(true);
    const response = await fetch("/api/lobbies", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "launch", code: activeLobby.code, playerId }) });
    setBusy(false);
    if (response.ok) launchLobby(activeLobby);
    else setError("Не удалось начать экспедицию");
  };

  const exitSession = async () => {
    if (session?.roomCode) {
      await fetch("/api/lobbies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "leave", code: session.roomCode, playerId }),
      }).catch(() => undefined);
    }
    setSession(null);
    setActiveLobby(null);
    setView("menu");
    void refreshLobbies();
  };

  const saveName = (value: string) => {
    const name = value.slice(0, 24);
    setPlayerName(name);
    localStorage.setItem("farhome-player-name", name);
  };

  const activeLobbies = useMemo(() => lobbies.filter((lobby) => lobby.status === "waiting"), [lobbies]);

  if (session) {
    return <GameView options={session} onExit={() => { void exitSession(); }} />;
  }

  return (
    <main className="menu-shell">
      <MenuPlanet seed={planetSeed} />
      <div className="menu-vignette" />
      <header className="menu-header">
        <div className="brand-mark"><span>FH</span><i /></div>
        <div className="header-status">
          <span className="status-dot" /> СВЯЗЬ СО СТАНЦИЕЙ
          <b>01</b>
        </div>
        <label className="callsign">ПОЗЫВНОЙ<input value={playerName} onChange={(event) => saveName(event.target.value)} maxLength={24} /></label>
      </header>

      <section className="menu-content">
        <div className="menu-kicker"><span>ГЛУБОКИЙ КОСМОС / 2189</span><i /></div>
        <h1>ДАЛЬШЕ<br /><em>ДОМА</em></h1>
        <p className="menu-tagline">Один старый корабль. Бесконечная случайная галактика.<br />Возвращаться необязательно.</p>

        {view === "menu" && (
          <div className="main-actions">
            <button className="action-primary" onClick={quickPlay} disabled={!playerId}>
              <span className="action-index">01</span><span><b>БЫСТРАЯ ИГРА</b><small>Одиночная песочница · мгновенный запуск</small></span><i>→</i>
            </button>
            <button className="action-secondary" onClick={() => { setView("create"); setError(""); }}>
              <span className="action-index">02</span><span><b>СОЗДАТЬ ЛОББИ</b><small>Стать хостом совместной экспедиции</small></span><i>+</i>
            </button>
            <button className="action-secondary" onClick={() => { setView("join"); setError(""); void refreshLobbies(); }}>
              <span className="action-index">03</span><span><b>ПРИСОЕДИНИТЬСЯ</b><small>Найти открытый канал или ввести код</small></span><i>→</i>
            </button>
            <button className="text-action" onClick={() => setView("manual")}>РУКОВОДСТВО СТРАННИКА <span>↗</span></button>
          </div>
        )}

        {view === "create" && (
          <div className="menu-form">
            <button className="back-button" onClick={() => setView("menu")}>← НАЗАД</button>
            <p className="panel-eyebrow">НОВЫЙ КАНАЛ ЭКСПЕДИЦИИ</p>
            <h2>Параметры лобби</h2>
            <label>Название<input value={title} onChange={(event) => setTitle(event.target.value)} maxLength={48} /></label>
            <label>Максимум странников <b>{maxPlayers}</b><input type="range" min="2" max="8" step="1" value={maxPlayers} onChange={(event) => setMaxPlayers(Number(event.target.value))} /></label>
            <div className="mode-picker">
              <button className={mode === "standard" ? "selected" : ""} onClick={() => setMode("standard")}><b>СТАНДАРТ</b><small>Консерва, пустые карманы и старый гараж. Полная выживательная экспедиция.</small></button>
              <button className={mode === "sandbox" ? "selected" : ""} onClick={() => setMode("sandbox")}><b>ПЕСОЧНИЦА</b><small>Клавиша B открывает спавнер любых предметов, ресурсов и существ.</small></button>
            </div>
            {error && <p className="form-error">{error}</p>}
            <button className="form-submit" onClick={() => void createLobby()} disabled={busy || !playerId}>{busy ? "ОТКРЫВАЕМ КАНАЛ…" : "СОЗДАТЬ И ВОЙТИ →"}</button>
          </div>
        )}

        {view === "join" && (
          <div className="menu-form join-form">
            <button className="back-button" onClick={() => setView("menu")}>← НАЗАД</button>
            <p className="panel-eyebrow">ПОИСК ЭКСПЕДИЦИЙ</p>
            <h2>Открытые каналы</h2>
            <div className="join-code"><input value={joinCode} onChange={(event) => setJoinCode(event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6))} placeholder="КОД ЛОББИ" /><button onClick={() => void joinLobby(joinCode)} disabled={busy || joinCode.length < 4}>ВОЙТИ</button></div>
            <div className="lobby-list">
              {activeLobbies.length === 0 && <div className="empty-lobbies"><span>ТИШИНА В ЭФИРЕ</span><p>Открытых лобби пока нет. Создайте своё — код появится здесь у других игроков.</p></div>}
              {activeLobbies.map((lobby) => <button key={lobby.code} onClick={() => void joinLobby(lobby.code)} disabled={busy || lobby.players >= lobby.maxPlayers}><span><b>{lobby.title}</b><small>{lobby.code} · {lobby.mode === "sandbox" ? "Песочница" : "Стандарт"} · хост {lobby.hostName}</small></span><strong>{lobby.players}/{lobby.maxPlayers}</strong></button>)}
            </div>
            {error && <p className="form-error">{error}</p>}
          </div>
        )}

        {view === "lobby" && activeLobby && (
          <div className="menu-form lobby-room">
            <p className="panel-eyebrow">КАНАЛ УСТАНОВЛЕН</p>
            <div className="room-code"><span>КОД ДЛЯ ДРУЗЕЙ</span><b>{activeLobby.code}</b></div>
            <h2>{activeLobby.title}</h2>
            <div className="room-meta"><span>{activeLobby.mode === "sandbox" ? "ПЕСОЧНИЦА" : "СТАНДАРТ"}</span><span>SEED {activeLobby.worldSeed}</span></div>
            <div className="member-list">
              {members.map((member, index) => <div key={member.playerId}><span className="member-avatar">{String(index + 1).padStart(2, "0")}</span><b>{member.name}</b><small>{member.playerId === activeLobby.hostId ? "ХОСТ" : "ГОТОВ"}</small></div>)}
              {Array.from({ length: Math.max(0, activeLobby.maxPlayers - members.length) }).map((_, index) => <div className="empty-member" key={index}><span className="member-avatar">--</span><b>Ожидание сигнала…</b></div>)}
            </div>
            {activeLobby.hostId === playerId ? <button className="form-submit" onClick={() => void hostLaunch()} disabled={busy}>НАЧАТЬ ЭКСПЕДИЦИЮ →</button> : <div className="waiting-host"><span className="status-dot" /> Хост выбирает момент запуска</div>}
            <button className="text-action" onClick={() => void leaveLobby()}>ПОКИНУТЬ ЛОББИ</button>
            {error && <p className="form-error">{error}</p>}
          </div>
        )}

        {view === "manual" && (
          <div className="menu-form manual-panel">
            <button className="back-button" onClick={() => setView("menu")}>← НАЗАД</button>
            <p className="panel-eyebrow">ПОЛЕВОЕ РУКОВОДСТВО / 01</p>
            <h2>От банки до звёзд</h2>
            <ol><li><b>Проснитесь.</b><span>Обыщите дом и гараж. Найдите катушку, обшивку и навигационный блок.</span></li><li><b>Почините корабль.</b><span>Подойдите к ржавому корпусу, соберите его и вставьте топливный элемент.</span></li><li><b>Выберите даль.</b><span>WASD — тяга, мышь — курс. Подлетите к планете и нажмите E для посадки.</span></li><li><b>Выживите.</b><span>ЛКМ — мультитул. Добывайте жилы, ломайте машины, следите за кислородом.</span></li></ol>
            <div className="control-grid"><span><kbd>WASD</kbd> движение</span><span><kbd>E</kbd> действие</span><span><kbd>M</kbd> звёздная карта</span><span><kbd>TAB</kbd> инвентарь</span><span><kbd>R</kbd> сканер</span><span><kbd>B</kbd> песочница</span><span><kbd>F</kbd> фонарь</span><span><kbd>1 / 2</kbd> припасы</span></div>
          </div>
        )}
      </section>

      <aside className="online-panel">
        <div className="online-counts"><div><b>{presence.playing}</b><span>СЕЙЧАС В ИГРЕ</span></div><i /><div><b>{presence.online}</b><span>В СЕТИ, НЕ В ИГРЕ</span></div></div>
        <div className="planet-caption"><span>ОБЪЕКТ / {String(planetSeed).slice(-6)}</span><b>НЕИЗВЕСТНАЯ ПЛАНЕТА</b><small>Процедурная модель · live</small></div>
        <button className="regenerate" onClick={() => setPlanetSeed(Math.floor(Math.random() * 2_000_000_000))}>ДРУГОЙ МИР <span>↻</span></button>
      </aside>

      <footer className="menu-footer"><span>BUILD 0.9.7 // FARHOME INITIATIVE</span><span>StarAlgo relay + local fallback</span><span className="archive-ticker">{discoveries[0] ? `АРХИВ: ${discoveries[0].playerName} открыл ${discoveries[0].planetName} / ${BIOME_NAMES[discoveries[0].biome] || discoveries[0].biome}` : "ГАЛАКТИЧЕСКИЙ АРХИВ ЖДЁТ ПЕРВОГО ОТКРЫТИЯ"}</span></footer>
    </main>
  );
}
