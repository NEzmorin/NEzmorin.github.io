"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";
import { mulberry32 } from "@/lib/game/procedural";

export default function MenuPlanet({ seed }: { seed: number }) {
  const mount = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = mount.current;
    if (!element) return;
    const random = mulberry32(seed);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.6));
    renderer.setSize(element.clientWidth, element.clientHeight);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    element.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, element.clientWidth / element.clientHeight, 0.1, 500);
    camera.position.set(0, 0.1, 8.6);
    const planetGroup = new THREE.Group();
    planetGroup.rotation.z = -0.18 - random() * 0.25;
    scene.add(planetGroup);

    const width = 512;
    const height = 256;
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext("2d")!;
    const image = context.createImageData(width, height);
    const palettes = [
      [[16, 30, 35], [38, 67, 66], [106, 116, 81], [178, 157, 105]],
      [[25, 20, 29], [65, 48, 55], [134, 83, 61], [205, 151, 99]],
      [[13, 26, 43], [37, 73, 93], [104, 144, 146], [197, 214, 197]],
      [[21, 27, 23], [52, 74, 48], [111, 133, 75], [184, 182, 121]],
    ];
    const palette = palettes[Math.floor(random() * palettes.length)];
    const phases = Array.from({ length: 10 }, () => random() * 12);
    for (let y = 0; y < height; y += 1) {
      for (let x = 0; x < width; x += 1) {
        const u = x / width;
        const v = y / height;
        const longitude = u * Math.PI * 2;
        const latitude = v * Math.PI;
        const broad = Math.sin(longitude * 2 + phases[0]) * Math.cos(latitude * 3 + phases[1]) + Math.sin(longitude * 5 - latitude * 4 + phases[2]) * 0.55 + Math.cos(longitude * 9 + latitude * 7 + phases[3]) * 0.25;
        const detail = Math.sin(longitude * 22 + Math.cos(latitude * 14) + phases[4]) * 0.13 + Math.cos(longitude * 41 - latitude * 33 + phases[5]) * 0.08;
        const value = THREE.MathUtils.clamp((broad + detail + 1.1) / 2.35, 0, 0.999);
        const band = Math.min(2, Math.floor(value * 3));
        const blend = value * 3 - band;
        const a = palette[band];
        const b = palette[band + 1];
        const index = (y * width + x) * 4;
        const polar = Math.abs(v - 0.5) * 2;
        const ice = polar > 0.82 + Math.sin(longitude * 5) * 0.035 ? 0.75 : 0;
        image.data[index] = a[0] + (b[0] - a[0]) * blend + (210 - (a[0] + (b[0] - a[0]) * blend)) * ice;
        image.data[index + 1] = a[1] + (b[1] - a[1]) * blend + (220 - (a[1] + (b[1] - a[1]) * blend)) * ice;
        image.data[index + 2] = a[2] + (b[2] - a[2]) * blend + (216 - (a[2] + (b[2] - a[2]) * blend)) * ice;
        image.data[index + 3] = 255;
      }
    }
    context.putImageData(image, 0, 0);
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.wrapS = THREE.RepeatWrapping;
    const geometry = new THREE.SphereGeometry(2.55, 128, 80);
    const positions = geometry.attributes.position;
    for (let i = 0; i < positions.count; i += 1) {
      const vector = new THREE.Vector3().fromBufferAttribute(positions, i);
      const normal = vector.clone().normalize();
      const displacement = Math.sin(normal.x * 18 + phases[6]) * Math.sin(normal.y * 15 + phases[7]) * 0.018 + Math.cos(normal.z * 25) * 0.008;
      vector.setLength(2.55 + displacement);
      positions.setXYZ(i, vector.x, vector.y, vector.z);
    }
    geometry.computeVertexNormals();
    const planet = new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({ map: texture, roughness: 0.88, metalness: 0.02, bumpMap: texture, bumpScale: 0.045 }));
    planetGroup.add(planet);

    const cloudCanvas = document.createElement("canvas");
    cloudCanvas.width = 512;
    cloudCanvas.height = 256;
    const cloudContext = cloudCanvas.getContext("2d")!;
    cloudContext.clearRect(0, 0, 512, 256);
    for (let i = 0; i < 130; i += 1) {
      const x = random() * 512;
      const y = 25 + random() * 205;
      const radius = 4 + random() * 20;
      const gradient = cloudContext.createRadialGradient(x, y, 0, x, y, radius);
      gradient.addColorStop(0, `rgba(225,235,218,${0.1 + random() * 0.22})`);
      gradient.addColorStop(1, "rgba(225,235,218,0)");
      cloudContext.fillStyle = gradient;
      cloudContext.fillRect(x - radius, y - radius, radius * 2, radius * 2);
    }
    const cloudTexture = new THREE.CanvasTexture(cloudCanvas);
    const clouds = new THREE.Mesh(new THREE.SphereGeometry(2.59, 80, 50), new THREE.MeshStandardMaterial({ map: cloudTexture, transparent: true, opacity: 0.7, depthWrite: false, roughness: 1 }));
    planetGroup.add(clouds);
    const atmosphere = new THREE.Mesh(new THREE.SphereGeometry(2.72, 64, 40), new THREE.ShaderMaterial({
      transparent: true,
      side: THREE.BackSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      vertexShader: "varying vec3 vNormal; varying vec3 vPosition; void main(){vNormal=normalize(normalMatrix*normal); vec4 mv=modelViewMatrix*vec4(position,1.);vPosition=mv.xyz;gl_Position=projectionMatrix*mv;}",
      fragmentShader: "varying vec3 vNormal; varying vec3 vPosition; void main(){float rim=pow(0.72-dot(normalize(vNormal),normalize(-vPosition)),3.0);gl_FragColor=vec4(0.32,0.66,0.65,rim*0.72);}",
    }));
    planetGroup.add(atmosphere);
    if (random() > 0.58) {
      const ring = new THREE.Mesh(new THREE.RingGeometry(3.2, 4.35, 128), new THREE.MeshStandardMaterial({ color: "#8c8873", transparent: true, opacity: 0.28, side: THREE.DoubleSide, roughness: 1, depthWrite: false }));
      ring.rotation.x = Math.PI / 2.45;
      ring.rotation.y = 0.2;
      planetGroup.add(ring);
    }
    scene.add(new THREE.AmbientLight("#31434c", 0.5));
    const key = new THREE.DirectionalLight("#f5ddb0", 4.2);
    key.position.set(-5, 3, 5);
    scene.add(key);
    const rim = new THREE.DirectionalLight("#5b9ca4", 2.1);
    rim.position.set(5, -1, -4);
    scene.add(rim);
    const starPositions: number[] = [];
    for (let i = 0; i < 650; i += 1) starPositions.push((random() - 0.5) * 90, (random() - 0.5) * 55, -8 - random() * 80);
    const starGeometry = new THREE.BufferGeometry();
    starGeometry.setAttribute("position", new THREE.Float32BufferAttribute(starPositions, 3));
    const stars = new THREE.Points(starGeometry, new THREE.PointsMaterial({ color: "#d5ded3", size: 0.07, transparent: true, opacity: 0.72 }));
    scene.add(stars);
    let mouseX = 0;
    let mouseY = 0;
    const onMouse = (event: MouseEvent) => {
      mouseX = (event.clientX / window.innerWidth - 0.5) * 0.3;
      mouseY = (event.clientY / window.innerHeight - 0.5) * 0.2;
    };
    const onResize = () => {
      renderer.setSize(element.clientWidth, element.clientHeight);
      camera.aspect = element.clientWidth / element.clientHeight;
      camera.updateProjectionMatrix();
    };
    window.addEventListener("mousemove", onMouse);
    window.addEventListener("resize", onResize);
    let frame = 0;
    let previous = performance.now();
    const animate = (time: number) => {
      frame = requestAnimationFrame(animate);
      const dt = Math.min(0.04, (time - previous) / 1000);
      previous = time;
      planet.rotation.y += dt * 0.055;
      clouds.rotation.y += dt * 0.075;
      planetGroup.rotation.y += (mouseX - planetGroup.rotation.y) * dt * 0.5;
      planetGroup.rotation.x += (-mouseY - planetGroup.rotation.x) * dt * 0.5;
      stars.rotation.y += dt * 0.0015;
      renderer.render(scene, camera);
    };
    frame = requestAnimationFrame(animate);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("mousemove", onMouse);
      window.removeEventListener("resize", onResize);
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh || object instanceof THREE.Points) {
          object.geometry.dispose();
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach((item) => item.dispose());
        }
      });
      texture.dispose();
      cloudTexture.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, [seed]);

  return <div ref={mount} className="menu-planet" aria-label="Вращающаяся процедурная планета" />;
}
