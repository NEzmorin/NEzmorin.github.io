import { NextRequest, NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { discoveries } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(discoveries).orderBy(desc(discoveries.discoveredAt)).limit(8);
    return NextResponse.json({ discoveries: rows });
  } catch {
    return NextResponse.json({ discoveries: [] });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as Record<string, string>;
    if (!body.playerId || !body.planetKey || !body.planetName) {
      return NextResponse.json({ error: "Недостаточно данных" }, { status: 400 });
    }
    await db.insert(discoveries).values({
      playerId: body.playerId.slice(0, 80),
      playerName: (body.playerName || "Странник").slice(0, 32),
      planetKey: body.planetKey.slice(0, 100),
      planetName: body.planetName.slice(0, 48),
      systemName: (body.systemName || "Неизвестная система").slice(0, 48),
      biome: (body.biome || "unknown").slice(0, 32),
    }).onConflictDoNothing();
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Архив временно недоступен" }, { status: 500 });
  }
}
