import { NextRequest, NextResponse } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { lobbies, lobbyMembers } from "@/db/schema";

export const dynamic = "force-dynamic";

type LobbyBody = {
  action?: "create" | "join" | "leave" | "launch";
  code?: string;
  playerId?: string;
  name?: string;
  title?: string;
  mode?: "standard" | "sandbox";
  maxPlayers?: number;
};

async function getLobbies(code?: string) {
  const conditions = code ? eq(lobbies.code, code.toUpperCase()) : sql`${lobbies.createdAt} > now() - interval '12 hours'`;
  const rows = await db
    .select({
      code: lobbies.code,
      hostId: lobbies.hostId,
      hostName: lobbies.hostName,
      title: lobbies.title,
      mode: lobbies.mode,
      maxPlayers: lobbies.maxPlayers,
      worldSeed: lobbies.worldSeed,
      status: lobbies.status,
      players: sql<number>`count(${lobbyMembers.id})::int`,
    })
    .from(lobbies)
    .leftJoin(lobbyMembers, eq(lobbyMembers.lobbyCode, lobbies.code))
    .where(conditions)
    .groupBy(lobbies.code)
    .orderBy(lobbies.createdAt);
  return rows.reverse();
}

export async function GET(request: NextRequest) {
  try {
    const code = request.nextUrl.searchParams.get("code") || undefined;
    const list = await getLobbies(code);
    if (code) {
      const members = await db.select().from(lobbyMembers).where(eq(lobbyMembers.lobbyCode, code.toUpperCase()));
      return NextResponse.json({ lobby: list[0] ?? null, members });
    }
    return NextResponse.json({ lobbies: list });
  } catch {
    return NextResponse.json({ error: "Не удалось получить лобби" }, { status: 500 });
  }
}

function cleanCode(value: string) {
  return value.toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 12);
}

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as LobbyBody;
    const playerId = body.playerId?.trim();
    const name = (body.name || "Странник").trim().slice(0, 32) || "Странник";
    if (!playerId || playerId.length > 80) return NextResponse.json({ error: "Некорректный ID" }, { status: 400 });

    if (body.action === "create") {
      const maxPlayers = Math.max(2, Math.min(8, Math.round(body.maxPlayers || 4)));
      let code = "";
      for (let attempt = 0; attempt < 8; attempt += 1) {
        code = Math.random().toString(36).slice(2, 8).toUpperCase().padEnd(6, "X");
        const existing = await db.select({ code: lobbies.code }).from(lobbies).where(eq(lobbies.code, code));
        if (!existing.length) break;
      }
      const worldSeed = Math.floor(Math.random() * 2_000_000_000);
      const title = (body.title || `Экспедиция ${name}`).trim().slice(0, 48);
      await db.insert(lobbies).values({
        code,
        hostId: playerId,
        hostName: name,
        title,
        mode: body.mode === "sandbox" ? "sandbox" : "standard",
        maxPlayers,
        worldSeed,
      });
      await db.insert(lobbyMembers).values({ lobbyCode: code, playerId, name });
      return NextResponse.json({ code, worldSeed });
    }

    const code = cleanCode(body.code || "");
    const lobby = (await db.select().from(lobbies).where(eq(lobbies.code, code)))[0];
    if (!lobby) return NextResponse.json({ error: "Лобби не найдено" }, { status: 404 });

    if (body.action === "join") {
      if (lobby.status !== "waiting") return NextResponse.json({ error: "Экспедиция уже началась" }, { status: 409 });
      const members = await db.select().from(lobbyMembers).where(eq(lobbyMembers.lobbyCode, code));
      if (!members.some((member) => member.playerId === playerId) && members.length >= lobby.maxPlayers) {
        return NextResponse.json({ error: "В лобби нет свободных мест" }, { status: 409 });
      }
      await db.insert(lobbyMembers).values({ lobbyCode: code, playerId, name }).onConflictDoNothing();
      await db.update(lobbies).set({ updatedAt: new Date() }).where(eq(lobbies.code, code));
      return NextResponse.json({ code, worldSeed: lobby.worldSeed });
    }

    if (body.action === "launch") {
      if (lobby.hostId !== playerId) return NextResponse.json({ error: "Запуск доступен только хосту" }, { status: 403 });
      await db.update(lobbies).set({ status: "playing", updatedAt: new Date() }).where(eq(lobbies.code, code));
      return NextResponse.json({ ok: true });
    }

    if (body.action === "leave") {
      await db.delete(lobbyMembers).where(and(eq(lobbyMembers.lobbyCode, code), eq(lobbyMembers.playerId, playerId)));
      if (lobby.hostId === playerId) await db.delete(lobbies).where(eq(lobbies.code, code));
      return NextResponse.json({ ok: true });
    }
    return NextResponse.json({ error: "Неизвестное действие" }, { status: 400 });
  } catch {
    return NextResponse.json({ error: "Операция с лобби не выполнена" }, { status: 500 });
  }
}
