import { NextRequest, NextResponse } from "next/server";
import { and, eq, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import { presence } from "@/db/schema";

export const dynamic = "force-dynamic";

async function counters() {
  await db.delete(presence).where(sql`${presence.lastSeen} < now() - interval '2 minutes'`);
  const rows = await db
    .select({ status: presence.status, count: sql<number>`count(*)::int` })
    .from(presence)
    .where(sql`${presence.lastSeen} > now() - interval '45 seconds'`)
    .groupBy(presence.status);
  const playing = rows.find((row) => row.status === "playing")?.count ?? 0;
  const online = rows.find((row) => row.status === "online")?.count ?? 0;
  return { playing, online, total: playing + online };
}

export async function GET() {
  return NextResponse.json(await counters());
}

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as { playerId?: string; name?: string; status?: string };
    if (!body.playerId || body.playerId.length > 80) {
      return NextResponse.json({ error: "Некорректный ID" }, { status: 400 });
    }
    const status = body.status === "playing" ? "playing" : "online";
    const name = (body.name || "Странник").trim().slice(0, 32) || "Странник";
    await db
      .insert(presence)
      .values({ playerId: body.playerId, name, status, lastSeen: new Date() })
      .onConflictDoUpdate({
        target: presence.playerId,
        set: { name, status, lastSeen: new Date() },
      });
    return NextResponse.json(await counters());
  } catch {
    return NextResponse.json({ error: "Служба присутствия недоступна" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const playerId = request.nextUrl.searchParams.get("playerId");
  if (playerId) {
    await db.delete(presence).where(and(eq(presence.playerId, playerId), ne(presence.playerId, "")));
  }
  return NextResponse.json({ ok: true });
}
