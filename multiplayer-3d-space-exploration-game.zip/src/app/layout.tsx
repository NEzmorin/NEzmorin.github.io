import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Дальше Дома — процедурная космическая экспедиция",
  description: "3D-исследование случайной галактики в одиночку и с друзьями. Почините корабль, откройте звёздную карту и выживите на неизвестных планетах.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#070c0e",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="ru"><body>{children}</body></html>;
}
